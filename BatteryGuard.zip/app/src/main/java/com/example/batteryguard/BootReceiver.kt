package com.example.batteryguard

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (Prefs.isEnabled(context) && Perms.overlay(context)) {
            try {
                context.startForegroundService(Intent(context, BatteryService::class.java))
            } catch (_: Exception) {
            }
        }
    }
}
