package com.example.batteryguard

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.app.ActivityManager
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MonitorService : Service() {
    private val handler = Handler(Looper.getMainLooper())
    private var bubble: FloatingBubble? = null
    private val update = object : Runnable { override fun run() { if (!Prefs.isEnabled(this@MonitorService)) { stopSelf(); return }; refreshOverlay(); handler.postDelayed(this, 3000) } }
    override fun onCreate() { super.onCreate(); createChannel(); startForeground(NOTIFICATION_ID, notification()); if (Prefs.overlay(this)) bubble = FloatingBubble(this, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY); handler.post(update) }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int { if (intent?.action == ACTION_STOP) { Prefs.setEnabled(this, false); stopSelf(); return START_NOT_STICKY }; if (!Prefs.isEnabled(this)) { stopSelf(); return START_NOT_STICKY }; if (bubble == null && Prefs.overlay(this)) bubble = FloatingBubble(this, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY); refreshOverlay(); return START_STICKY }
    override fun onBind(intent: Intent?): IBinder? = null
    override fun onDestroy() { handler.removeCallbacksAndMessages(null); bubble?.hide(); bubble = null; Prefs.setEnabled(this, false); stopForeground(STOP_FOREGROUND_REMOVE); super.onDestroy() }
    private fun refreshOverlay() {
        if (!Prefs.overlay(this)) { bubble?.hide(); return }
        val values = LinkedHashMap<String, String>()
        Prefs.metrics(this).forEach { key -> metric(key)?.let { values[key] = it } }
        if (values.isEmpty()) { bubble?.hide(); return }
        if (bubble == null) bubble = FloatingBubble(this, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY)
        bubble?.show(values)
    }
    private fun metric(key: String): String? = when (key) {
        "cpu" -> "${CpuUsage.read()}%"
        "temp" -> CpuTemp.read()?.let { String.format(Locale.getDefault(), "%.1f °C", it) } ?: "—"
        "gpu" -> gpuValue()
        "ram" -> { val am = getSystemService(ACTIVITY_SERVICE) as ActivityManager; val mi = ActivityManager.MemoryInfo(); am.getMemoryInfo(mi); "${((mi.totalMem-mi.availMem)/1048576L)} / ${mi.totalMem/1048576L} MB" }
        "time" -> SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
        "battery" -> { val i = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)); val level=i?.getIntExtra(BatteryManager.EXTRA_LEVEL,-1) ?: -1; val scale=i?.getIntExtra(BatteryManager.EXTRA_SCALE,100) ?: 100; if(level>=0) "${level*100/scale}%" else "—" }
        else -> null
    }
    private fun gpuValue(): String {
        val candidates = listOf("/sys/class/kgsl/kgsl-3d0/gpuclk", "/sys/class/devfreq/1c00000.mali/cur_freq", "/sys/class/devfreq/gpu/cur_freq")
        for (p in candidates) try { val n = File(p).readText().trim().toLongOrNull() ?: continue; return "${if(n>1000000) n/1000000 else n/1000} MHz" } catch (_: Exception) {}
        return "н/д"
    }
    private fun createChannel() { if (Build.VERSION.SDK_INT >= 26) { val c=NotificationChannel(CHANNEL, "BatteryGuard", NotificationManager.IMPORTANCE_LOW).apply { description="Постоянная работа плавающего окна"; setShowBadge(false) }; getSystemService(NotificationManager::class.java).createNotificationChannel(c) } }
    private fun notification(): Notification {
        val stop=Intent(this, MonitorService::class.java).setAction(ACTION_STOP)
        val pi=PendingIntent.getService(this, 1, stop, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val open=PendingIntent.getActivity(this, 2, Intent(this, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_thermo)
            .setContentTitle("BatteryGuard работает")
            .setContentText("Плавающие системные показатели активны")
            .setContentIntent(open)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setOngoing(true).setOnlyAlertOnce(true)
            .addAction(R.drawable.ic_thermo, "Выключить", pi).build()
    }
    override fun onTaskRemoved(rootIntent: Intent?) { super.onTaskRemoved(rootIntent) }
    companion object { const val CHANNEL="batteryguard_monitor"; const val NOTIFICATION_ID=41; const val ACTION_STOP="batteryguard.STOP" }
}

private object CpuUsage {
    private var previousTotal=0L; private var previousIdle=0L
    @Synchronized fun read(): Int {
        return try { val parts=File("/proc/stat").readLines().first().trim().split(Regex("\\s+")); val nums=parts.drop(1).map { it.toLong() }; val idle=nums[3]+(nums.getOrNull(4) ?: 0L); val total=nums.sum(); val dt=total-previousTotal; val di=idle-previousIdle; previousTotal=total; previousIdle=idle; if(dt<=0) 0 else ((100*(dt-di)/dt).toInt()).coerceIn(0,100) } catch (_: Exception) { 0 }
    }
}
