package com.example.batteryguard

import android.app.PendingIntent
import android.content.Intent
import android.content.SharedPreferences
import android.os.Build
import android.provider.Settings
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

class ToggleTileService : TileService() {

    private val listener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        if (key == "enabled") refresh()
    }

    override fun onStartListening() {
        Prefs.sp(this).registerOnSharedPreferenceChangeListener(listener)
        refresh()
    }

    override fun onStopListening() {
        Prefs.sp(this).unregisterOnSharedPreferenceChangeListener(listener)
    }

    override fun onClick() {
        if (!Perms.accessibility(this)) {
            openSettings(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            return
        }
        Prefs.setEnabled(this, !Prefs.isEnabled(this))
        refresh()
    }

    private fun refresh() {
        val tile = qsTile ?: return
        val on = Prefs.isEnabled(this) && Perms.accessibility(this)
        tile.state = if (on) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        tile.updateTile()
    }

    @Suppress("DEPRECATION")
    private fun openSettings(i: Intent) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (Build.VERSION.SDK_INT >= 34) {
            startActivityAndCollapse(
                PendingIntent.getActivity(this, 0, i, PendingIntent.FLAG_IMMUTABLE)
            )
        } else {
            startActivityAndCollapse(i)
        }
    }
}
