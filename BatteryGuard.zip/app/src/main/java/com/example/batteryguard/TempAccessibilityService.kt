package com.example.batteryguard

import android.accessibilityservice.AccessibilityService
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.os.BatteryManager
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityWindowInfo
import android.view.inputmethod.InputMethodManager

class TempAccessibilityService : AccessibilityService() {

    private val handler = Handler(Looper.getMainLooper())
    private var bubble: FloatingBubble? = null
    private var fgPkg: String? = null
    private var pendingPkg: String? = null
    private val packageSwitch = Runnable {
        val next = pendingPkg
        pendingPkg = null
        val target = activeAppPkg() ?: next
        if (target != null && target != fgPkg && isCandidate(target)) {
            fgPkg = target
            evaluate(false)
        }
    }
    private val verify = Runnable { sync() }
    private var polling = false
    private var visible = false
    private var lastB: String? = null
    private var lastC: String? = null
    private var lastAlert = false
    private var cpuShown: Float? = null
    private var cpuPending = false

    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        if (key == "size") bubble?.applySize(Prefs.size(this))
        if (key == "alpha") bubble?.applyAlpha(Prefs.alpha(this))
        if (key != "x" && key != "y") evaluate(true)
    }

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) = evaluate(true)
    }

    private val poller = object : Runnable {
        override fun run() {
            tick()
            if (polling) handler.postDelayed(this, INTERVAL)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        bubble = FloatingBubble(this, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY)
        registerReceiver(screenReceiver, IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_SCREEN_ON)
        })
        Prefs.sp(this).registerOnSharedPreferenceChangeListener(prefListener)
        evaluate(false)
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent) {
        if (e.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = e.packageName?.toString() ?: return
        if (pkg == packageName && e.className?.startsWith(packageName) != true) return
        if (pkg == fgPkg) {
            handler.removeCallbacks(packageSwitch)
            pendingPkg = null
            return
        }
        if (!isCandidate(pkg)) return

        // Avoid hiding the overlay because Android briefly reports a transition window.
        handler.removeCallbacks(packageSwitch)
        pendingPkg = pkg
        if (Prefs.apps(this).contains(pkg)) {
            pendingPkg = null
            fgPkg = pkg
            evaluate(false)
            handler.removeCallbacks(verify)
            handler.postDelayed(verify, VERIFY_DELAY)
        } else {
            handler.postDelayed(packageSwitch, PACKAGE_SWITCH_DELAY)
        }
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        pendingPkg = null
        try {
            unregisterReceiver(screenReceiver)
        } catch (_: Exception) {
        }
        Prefs.sp(this).unregisterOnSharedPreferenceChangeListener(prefListener)
        hideBubble()
        super.onDestroy()
    }

    private fun isCandidate(pkg: String) = pkg !in IGNORED && pkg !in imePackages()

    private fun activeAppPkg(): String? {
        return try {
            var best: AccessibilityWindowInfo? = null
            for (w in windows) {
                if (w.type != AccessibilityWindowInfo.TYPE_APPLICATION) continue
                if (w.isActive) {
                    best = w
                    break
                }
                if (best == null && w.isFocused) best = w
            }
            best?.root?.packageName?.toString()
        } catch (_: Exception) {
            null
        }
    }

    private fun sync() {
        val real = activeAppPkg() ?: return
        if (real != fgPkg && isCandidate(real)) {
            handler.removeCallbacks(packageSwitch)
            pendingPkg = null
            fgPkg = real
            evaluate(false)
        }
    }

    private fun imePackages(): Set<String> {
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        return imm.enabledInputMethodList.map { it.packageName }.toSet()
    }

    private fun evaluate(force: Boolean) {
        val interactive = (getSystemService(Context.POWER_SERVICE) as PowerManager).isInteractive
        val pkg = fgPkg
        val inApp = Prefs.isEnabled(this) && interactive && pkg != null && pkg in Prefs.apps(this)
        if (!inApp) {
            handler.removeCallbacks(poller)
            polling = false
            hideBubble()
            return
        }
        if (polling && !force) return
        handler.removeCallbacks(poller)
        polling = true
        handler.post(poller)
    }

    private fun hideBubble() {
        bubble?.hide()
        visible = false
        lastB = null
        lastC = null
        cpuShown = null
        cpuPending = false
    }

    private fun filterCpu(v: Float?): Float? {
        if (v == null) return cpuShown
        val prev = cpuShown
        if (prev != null && v - prev > JUMP && !cpuPending) {
            cpuPending = true
            return prev
        }
        cpuPending = false
        cpuShown = v
        return v
    }

    private fun tick() {
        sync()
        if (!polling) return
        val mode = Prefs.mode(this)
        val wantBatt = mode != 1
        val wantCpu = mode != 0

        var batt: Float? = null
        if (wantBatt) {
            val i = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val raw = i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE) ?: Int.MIN_VALUE
            if (raw != Int.MIN_VALUE) batt = raw / 10f
        }
        val cpu = if (wantCpu) filterCpu(CpuTemp.read()) else null

        val alert = (batt != null && batt >= Prefs.threshold(this)) ||
            (cpu != null && cpu >= Prefs.cpuThreshold(this))

        val b = if (wantBatt) (if (batt != null) String.format(java.util.Locale.US, "%.1f°", batt) else "—") else null
        val c = if (wantCpu) (if (cpu != null) String.format(java.util.Locale.US, "%d°", Math.round(cpu)) else "—") else null

        if (!visible || b != lastB || c != lastC || alert != lastAlert) {
            visible = bubble?.show(b, c, alert) == true
            lastB = b
            lastC = c
            lastAlert = alert
        }
    }

    companion object {
        private const val INTERVAL = 3000L
        private const val PACKAGE_SWITCH_DELAY = 500L
        private const val VERIFY_DELAY = 700L
        private const val JUMP = 8f
        private val IGNORED = setOf("com.android.systemui", "android")
    }
}
