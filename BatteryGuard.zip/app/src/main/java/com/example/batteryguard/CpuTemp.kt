package com.example.batteryguard

import java.io.File

object CpuTemp {

    private var paths: List<String>? = null

    private val include = listOf(
        "cpu", "soc", "tsens", "apc", "big", "little", "mid", "cluster",
        "mtk", "pkg_temp", "core", "k10temp", "coretemp"
    )
    private val exclude = listOf(
        "batt", "charger", "usb", "gpu", "modem", "wifi", "pa-", "quiet", "skin", "chg"
    )

    fun read(): Float? {
        val list = paths ?: discover().also { paths = it }
        var max: Float? = null
        for (p in list) {
            val v = readTemp(p) ?: continue
            if (max == null || v > max) max = v
        }
        return max
    }

    private fun readTemp(path: String): Float? {
        return try {
            val raw = File(path).readText().trim().toFloatOrNull() ?: return null
            val c = if (raw >= 1000f) raw / 1000f else raw
            if (c in 10f..125f) c else null
        } catch (_: Exception) {
            null
        }
    }

    private fun matches(name: String): Boolean {
        val n = name.trim().lowercase()
        return include.any { n.contains(it) } && exclude.none { n.contains(it) }
    }

    private fun discover(): List<String> {
        val result = mutableListOf<String>()
        try {
            File("/sys/class/thermal").listFiles()?.forEach { dir ->
                if (dir.name.startsWith("thermal_zone")) {
                    val type = try {
                        File(dir, "type").readText()
                    } catch (_: Exception) {
                        ""
                    }
                    val temp = File(dir, "temp").path
                    if (matches(type) && readTemp(temp) != null) result.add(temp)
                }
            }
        } catch (_: Exception) {
        }
        try {
            File("/sys/class/hwmon").listFiles()?.forEach { dir ->
                val name = try {
                    File(dir, "name").readText()
                } catch (_: Exception) {
                    ""
                }
                if (matches(name)) {
                    dir.listFiles()?.forEach { f ->
                        if (f.name.startsWith("temp") && f.name.endsWith("_input") && readTemp(f.path) != null) {
                            result.add(f.path)
                        }
                    }
                }
            }
        } catch (_: Exception) {
        }
        return result
    }
}
