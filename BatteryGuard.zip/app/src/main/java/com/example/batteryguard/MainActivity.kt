package com.example.batteryguard

import android.content.res.ColorStateList
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.material.button.MaterialButton

class MainActivity : AppCompatActivity() {

    private lateinit var btn: MaterialButton
    private var pendingStart = false
    private var overlayPrompted = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btn = findViewById(R.id.btn)

        findViewById<android.view.View>(R.id.btnSettings).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        btn.setOnClickListener {
            if (isOn()) {
                stopMonitor()
            } else {
                overlayPrompted = false
                tryStart()
            }
        }
    }

    private fun isOn() = Prefs.isEnabled(this) && Perms.accessibility(this)

    override fun onResume() {
        super.onResume()
        updateUi()
        if (pendingStart) {
            pendingStart = false
            tryStart()
        }
    }

    private fun updateUi() {
        val on = isOn()
        btn.text = if (on) "Выключить" else "Включить"
        btn.backgroundTintList = ColorStateList.valueOf(
            ContextCompat.getColor(this, if (on) R.color.green_on else R.color.brand)
        )
    }

    private fun stopMonitor() {
        Prefs.setEnabled(this, false)
        updateUi()
    }

    private fun tryStart() {
        if (!Perms.accessibility(this)) {
            if (!overlayPrompted) {
                overlayPrompted = true
                pendingStart = true
                Toast.makeText(this, "Включите BatteryGuard в специальных возможностях", Toast.LENGTH_LONG).show()
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            } else {
                Toast.makeText(this, "Без службы специальных возможностей мониторинг не работает", Toast.LENGTH_LONG).show()
            }
            return
        }
        Prefs.setEnabled(this, true)
        updateUi()
    }
}
