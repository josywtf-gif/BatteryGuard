package com.example.batteryguard

import android.Manifest
import android.content.ColorStateList
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.material.button.MaterialButton

class MainActivity : AppCompatActivity() {

    private lateinit var btn: MaterialButton
    private var pendingStart = false
    private var overlayPrompted = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btn = findViewById(R.id.btn)

        findViewById<android.view.View>(R.id.btnSettings).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        btn.setOnClickListener {
            if (Prefs.isEnabled(this)) {
                stopMonitor()
            } else {
                overlayPrompted = false
                tryStart()
            }
        }
    }

    override fun onResume() {
        super.onResume()
        updateUi()
        if (pendingStart) {
            pendingStart = false
            tryStart()
        } else if (Prefs.isEnabled(this) && Perms.overlay(this)) {
            ContextCompat.startForegroundService(this, Intent(this, BatteryService::class.java))
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        tryStart()
    }

    private fun updateUi() {
        val on = Prefs.isEnabled(this)
        btn.text = if (on) "Выключить" else "Включить"
        btn.backgroundTintList = ColorStateList.valueOf(
            ContextCompat.getColor(this, if (on) R.color.green_on else R.color.brand)
        )
    }

    private fun stopMonitor() {
        stopService(Intent(this, BatteryService::class.java))
        Prefs.setEnabled(this, false)
        updateUi()
    }

    private fun tryStart() {
        if (!Perms.overlay(this)) {
            if (!overlayPrompted) {
                overlayPrompted = true
                pendingStart = true
                Toast.makeText(this, "Разрешите показ поверх других окон", Toast.LENGTH_LONG).show()
                startActivity(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                )
            } else {
                Toast.makeText(this, "Без разрешения окно показать нельзя", Toast.LENGTH_LONG).show()
            }
            return
        }

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED &&
            !Prefs.asked(this, "notif")
        ) {
            Prefs.setAsked(this, "notif")
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
            return
        }

        if (!Perms.ignoringBattery(this) && !Prefs.asked(this, "battery")) {
            Prefs.setAsked(this, "battery")
            try {
                pendingStart = true
                startActivity(
                    Intent(
                        Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                        Uri.parse("package:$packageName")
                    )
                )
            } catch (_: Exception) {
                pendingStart = false
                tryStart()
            }
            return
        }

        if (Prefs.apps(this).isNotEmpty() && !Perms.usage(this) && !Prefs.asked(this, "usage")) {
            Prefs.setAsked(this, "usage")
            try {
                pendingStart = true
                startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
            } catch (_: Exception) {
                pendingStart = false
                tryStart()
            }
            return
        }

        ContextCompat.startForegroundService(this, Intent(this, BatteryService::class.java))
        Prefs.setEnabled(this, true)
        updateUi()
    }
}
