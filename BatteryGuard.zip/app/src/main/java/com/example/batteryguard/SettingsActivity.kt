package com.example.batteryguard

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.slider.Slider
import kotlin.math.roundToInt

class SettingsActivity : AppCompatActivity() {

    private lateinit var tvApps: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        val tvThr: TextView = findViewById(R.id.tvThr)
        val tvSize: TextView = findViewById(R.id.tvSize)
        tvApps = findViewById(R.id.tvApps)
        val sliderThr: Slider = findViewById(R.id.sliderThr)
        val sliderSize: Slider = findViewById(R.id.sliderSize)

        findViewById<View>(R.id.btnBack).setOnClickListener { finish() }

        val t0 = ((Prefs.threshold(this) * 2).roundToInt() / 2f).coerceIn(35f, 55f)
        sliderThr.value = t0
        tvThr.text = String.format("%.1f °C", t0)
        sliderThr.addOnChangeListener { _, v, fromUser ->
            tvThr.text = String.format("%.1f °C", v)
            if (fromUser) Prefs.setThreshold(this, v)
        }

        val s0 = (((Prefs.size(this) - 24) / 2f).roundToInt() * 2 + 24).coerceIn(24, 96)
        sliderSize.value = s0.toFloat()
        tvSize.text = "$s0 dp"
        sliderSize.addOnChangeListener { _, v, fromUser ->
            tvSize.text = "${v.toInt()} dp"
            if (fromUser) Prefs.setSize(this, v.toInt())
        }

        findViewById<View>(R.id.cardApps).setOnClickListener {
            startActivity(Intent(this, AppsActivity::class.java))
        }
    }

    override fun onResume() {
        super.onResume()
        tvApps.text = "Выбрано: ${Prefs.apps(this).size}"
    }
}
