package com.example.batteryguard

import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.slider.Slider

class SettingsActivity : AppCompatActivity() {
    private val labels = mapOf("cpu" to "Процессор", "temp" to "Температура", "gpu" to "ГПУ", "ram" to "ОЗУ", "time" to "Время", "battery" to "Батарея")
    private val symbols = mapOf("cpu" to "◉", "temp" to "♨", "gpu" to "▦", "ram" to "▤", "time" to "◷", "battery" to "▰")
    private lateinit var list: LinearLayout
    private val checks = mutableMapOf<String, CheckBox>()
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContentView(R.layout.activity_settings)
        findViewById<View>(R.id.btnBack).setOnClickListener { finish() }
        list=findViewById(R.id.metricsList)
        renderMetrics()
        val size=findViewById<Slider>(R.id.sliderSize); val sizeText=findViewById<TextView>(R.id.tvSize); size.value=Prefs.size(this).toFloat().coerceIn(24f,96f); sizeText.text="${size.value.toInt()} dp"; size.addOnChangeListener { _,v,user -> sizeText.text="${v.toInt()} dp"; if(user) { Prefs.setSize(this,v.toInt()); sendRefresh() } }
        val alpha=findViewById<Slider>(R.id.sliderAlpha); val alphaText=findViewById<TextView>(R.id.tvAlpha); alpha.value=Prefs.alpha(this).toFloat().coerceIn(30f,100f); alphaText.text="${alpha.value.toInt()}%"; alpha.addOnChangeListener { _,v,user -> alphaText.text="${v.toInt()}%"; if(user) { Prefs.setAlpha(this,v.toInt()); sendRefresh() } }
    }
    private fun renderMetrics() {
        list.removeAllViews(); checks.clear()
        val active = Prefs.metrics(this)
        val order = active + Prefs.ALL_METRICS.filter { it !in active }
        order.forEachIndexed { index,key ->
            val row=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL; setPadding(8,6,4,6) }
            val icon=TextView(this).apply { text=symbols[key]; textSize=20f; setPadding(4,0,12,0) }
            val check=CheckBox(this).apply {
                text=labels[key]; isChecked=key in active
                layoutParams=LinearLayout.LayoutParams(0,LinearLayout.LayoutParams.WRAP_CONTENT,1f)
                setOnCheckedChangeListener { _,checked ->
                    val current=Prefs.metrics(this@SettingsActivity)
                    if(checked) { if(key !in current) current.add(key) } else current.remove(key)
                    Prefs.setMetrics(this@SettingsActivity,current); sendRefresh(); renderMetrics()
                }
            }
            checks[key]=check
            val activeIndex=active.indexOf(key)
            val up=ImageButton(this).apply { setImageResource(android.R.drawable.arrow_up_float); contentDescription="Переместить выше"; setBackgroundResource(android.R.drawable.list_selector_background); isEnabled=activeIndex>0; visibility=if(key in active) View.VISIBLE else View.INVISIBLE; setOnClickListener { move(key,-1) } }
            val down=ImageButton(this).apply { setImageResource(android.R.drawable.arrow_down_float); contentDescription="Переместить ниже"; setBackgroundResource(android.R.drawable.list_selector_background); isEnabled=activeIndex in 0 until active.lastIndex; visibility=if(key in active) View.VISIBLE else View.INVISIBLE; setOnClickListener { move(key,1) } }
            row.addView(icon); row.addView(check); row.addView(up,LinearLayout.LayoutParams(44,44)); row.addView(down,LinearLayout.LayoutParams(44,44)); list.addView(row)
            list.addView(View(this).apply { setBackgroundColor(0x22333333) },LinearLayout.LayoutParams(-1,1))
        }
    }
    private fun move(key:String,delta:Int) { val order=Prefs.metrics(this); val from=order.indexOf(key); val to=from+delta; if(from<0||to !in order.indices) return; val v=order.removeAt(from); order.add(to,v); Prefs.setMetrics(this,order); renderMetrics() }
    private fun sendRefresh() { if(Prefs.isEnabled(this)) startService(android.content.Intent(this,MonitorService::class.java)) }
}
