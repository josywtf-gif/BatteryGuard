package com.example.batteryguard

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButtonToggleGroup
import com.google.android.material.slider.Slider
import kotlin.math.roundToInt

class SettingsActivity : AppCompatActivity() {

    private lateinit var tvApps: TextView
    private lateinit var tvCpuHint: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        tvApps = findViewById(R.id.tvApps)
        tvCpuHint = findViewById(R.id.tvCpuHint)
        val tvThr: TextView = findViewById(R.id.tvThr)
        val tvCpuThr: TextView = findViewById(R.id.tvCpuThr)
        val tvSize: TextView = findViewById(R.id.tvSize)
        val tvAlpha: TextView = findViewById(R.id.tvAlpha)
        val sliderThr: Slider = findViewById(R.id.sliderThr)
        val sliderCpuThr: Slider = findViewById(R.id.sliderCpuThr)
        val sliderSize: Slider = findViewById(R.id.sliderSize)
        val sliderAlpha: Slider = findViewById(R.id.sliderAlpha)
        val group: MaterialButtonToggleGroup = findViewById(R.id.groupMode)

        findViewById<View>(R.id.btnBack).setOnClickListener { finish() }

        group.check(
            when (Prefs.mode(this)) {
                1 -> R.id.btnModeCpu
                2 -> R.id.btnModeBoth
                else -> R.id.btnModeBatt
            }
        )
        group.addOnButtonCheckedListener { _, id, checked ->
            if (checked) {
                Prefs.setMode(
                    this,
                    when (id) {
                        R.id.btnModeCpu -> 1
                        R.id.btnModeBoth -> 2
                        else -> 0
                    }
                )
                updateHint()
            }
        }
        updateHint()

        val t0 = ((Prefs.threshold(this) * 2).roundToInt() / 2f).coerceIn(35f, 55f)
        sliderThr.value = t0
        tvThr.text = String.format("%.1f °C", t0)
        sliderThr.addOnChangeListener { _, v, fromUser ->
            tvThr.text = String.format("%.1f °C", v)
            if (fromUser) Prefs.setThreshold(this, v)
        }

        val c0 = Prefs.cpuThreshold(this).roundToInt().coerceIn(40, 100)
        sliderCpuThr.value = c0.toFloat()
        tvCpuThr.text = "$c0 °C"
        sliderCpuThr.addOnChangeListener { _, v, fromUser ->
            tvCpuThr.text = "${v.toInt()} °C"
            if (fromUser) Prefs.setCpuThreshold(this, v)
        }

        val s0 = (((Prefs.size(this) - 24) / 2f).roundToInt() * 2 + 24).coerceIn(24, 96)
        sliderSize.value = s0.toFloat()
        tvSize.text = "$s0 dp"
        sliderSize.addOnChangeListener { _, v, fromUser ->
            tvSize.text = "${v.toInt()} dp"
            if (fromUser) Prefs.setSize(this, v.toInt())
        }

        val a0 = (((Prefs.alpha(this) - 30) / 5f).roundToInt() * 5 + 30).coerceIn(30, 100)
        sliderAlpha.value = a0.toFloat()
        tvAlpha.text = "$a0%"
        sliderAlpha.addOnChangeListener { _, v, fromUser ->
            tvAlpha.text = "${v.toInt()}%"
            if (fromUser) Prefs.setAlpha(this, v.toInt())
        }

        findViewById<View>(R.id.cardApps).setOnClickListener {
            startActivity(Intent(this, AppsActivity::class.java))
        }
    }

    override fun onResume() {
        super.onResume()
        tvApps.text = "Выбрано: ${Prefs.apps(this).size}"
    }

    private fun updateHint() {
        val unavailable = Prefs.mode(this) != 0 && CpuTemp.read() == null
        tvCpuHint.visibility = if (unavailable) View.VISIBLE else View.GONE
    }
}
