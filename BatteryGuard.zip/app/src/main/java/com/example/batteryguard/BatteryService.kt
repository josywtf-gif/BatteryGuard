package com.example.batteryguard

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager

class BatteryService : Service() {

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var bubble: FloatingBubble
    private val battSamples = ArrayDeque<Float>()
    private val cpuSamples = ArrayDeque<Float>()
    private var temp = 0f
    private var cpu: Float? = null
    private var fgPkg: String? = null
    private var alertOn = false
    private var lastBatt: String? = null
    private var lastCpuText: String? = null
    private var lastShownAlert = false
    private var visible = false
    private var lastEvents = 0L

    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        if (key == "size") bubble.applySize(Prefs.size(this))
        if (key == "alpha") bubble.applyAlpha(Prefs.alpha(this))
        if (key == "mode") cpuSamples.clear()
        if (key == "apps") {
            fgPkg = null
            lastEvents = 0L
        }
        if (key == "mode" || key == "apps") restartPoller() else refresh()
    }

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            if (i.action == Intent.ACTION_SCREEN_OFF) {
                handler.removeCallbacks(poller)
                bubble.hide()
                visible = false
                lastBatt = null
                lastCpuText = null
            } else {
                restartPoller()
            }
        }
    }

    private val poller = object : Runnable {
        override fun run() {
            sample()
            pollForeground()
            refresh()
            handler.postDelayed(this, nextDelay())
        }
    }

    private fun nextDelay(): Long {
        if (visible || Prefs.apps(this).isNotEmpty()) return INTERVAL
        val mode = Prefs.mode(this)
        val battNear = mode != 1 && temp >= Prefs.threshold(this) - MARGIN
        val cpuNear = mode != 0 && (cpu ?: 0f) >= Prefs.cpuThreshold(this) - MARGIN
        return if (battNear || cpuNear) INTERVAL else IDLE_INTERVAL
    }

    private fun restartPoller() {
        handler.removeCallbacks(poller)
        if (isInteractive()) handler.post(poller)
    }

    private fun isInteractive() =
        (getSystemService(Context.POWER_SERVICE) as PowerManager).isInteractive

    private fun median(q: ArrayDeque<Float>): Float {
        val l = q.sorted()
        return l[l.size / 2]
    }

    private fun push(q: ArrayDeque<Float>, v: Float) {
        q.addLast(v)
        while (q.size > WINDOW) q.removeFirst()
    }

    private fun sample() {
        val i = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val raw = i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE) ?: Int.MIN_VALUE
        if (raw != Int.MIN_VALUE) {
            push(battSamples, raw / 10f)
            temp = median(battSamples)
        }
        if (Prefs.mode(this) != 0) {
            val v = CpuTemp.read()
            if (v != null) {
                push(cpuSamples, v)
                cpu = median(cpuSamples)
            } else {
                cpuSamples.clear()
                cpu = null
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        bubble = FloatingBubble(this)

        val nm = getSystemService(NotificationManager::class.java)
        val channel = NotificationChannel(CH, "Служебное", NotificationManager.IMPORTANCE_MIN)
        channel.setShowBadge(false)
        nm.createNotificationChannel(channel)

        val n = Notification.Builder(this, CH)
            .setSmallIcon(R.drawable.ic_thermo)
            .setContentTitle("BatteryGuard")
            .setContentText("Мониторинг температуры")
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }

        registerReceiver(screenReceiver, IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_SCREEN_ON)
        })
        Prefs.sp(this).registerOnSharedPreferenceChangeListener(prefListener)
        restartPoller()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int) = START_STICKY

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        try {
            unregisterReceiver(screenReceiver)
        } catch (_: Exception) {
        }
        Prefs.sp(this).unregisterOnSharedPreferenceChangeListener(prefListener)
        bubble.hide()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    @Suppress("DEPRECATION")
    private fun pollForeground() {
        if (Prefs.apps(this).isEmpty() || !Perms.usage(this)) {
            fgPkg = null
            lastEvents = 0L
            return
        }
        val usm = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val now = System.currentTimeMillis()
        val from = if (lastEvents == 0L) now - 3_600_000L else lastEvents
        val events = usm.queryEvents(from, now)
        val e = UsageEvents.Event()
        while (events.hasNextEvent()) {
            events.getNextEvent(e)
            when (e.eventType) {
                UsageEvents.Event.MOVE_TO_FOREGROUND -> fgPkg = e.packageName
                UsageEvents.Event.MOVE_TO_BACKGROUND -> if (fgPkg == e.packageName) fgPkg = null
            }
        }
        lastEvents = now - 2000L
    }

    private fun refresh() {
        val mode = Prefs.mode(this)
        val wantBatt = mode != 1
        val wantCpu = mode != 0

        val cpuNow = cpu
        val bt = Prefs.threshold(this)
        val ct = Prefs.cpuThreshold(this)
        val battAlert = wantBatt && (if (alertOn) temp >= bt - HYST else temp >= bt)
        val cpuAlert = wantCpu && cpuNow != null && (if (alertOn) cpuNow >= ct - HYST else cpuNow >= ct)
        val alert = battAlert || cpuAlert
        alertOn = alert

        val pkg = fgPkg
        val inApp = pkg != null && pkg in Prefs.apps(this)
        val interactive = isInteractive()

        if (Perms.overlay(this) && interactive && (alert || inApp)) {
            val b = if (wantBatt) String.format("%.1f°", temp) else null
            val c = if (wantCpu) (if (cpuNow != null) String.format("%.0f°", cpuNow) else "—") else null
            if (!visible || b != lastBatt || c != lastCpuText || alert != lastShownAlert) {
                bubble.show(b, c, alert)
                lastBatt = b
                lastCpuText = c
                lastShownAlert = alert
                visible = true
            }
        } else {
            if (visible) bubble.hide()
            visible = false
            lastBatt = null
            lastCpuText = null
        }
    }

    companion object {
        private const val CH = "service"
        private const val INTERVAL = 5000L
        private const val IDLE_INTERVAL = 20000L
        private const val WINDOW = 3
        private const val MARGIN = 5f
        private const val HYST = 2f
    }
}
