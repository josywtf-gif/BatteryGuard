package com.example.batteryguard

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager

class BatteryService : Service() {

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var bubble: FloatingBubble
    private var fgPkg: String? = null
    private var lastEvents = 0L
    private var visible = false
    private var lastB: String? = null
    private var lastC: String? = null
    private var lastAlert = false
    private var cpuShown: Float? = null
    private var cpuPending = false

    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        if (key == "size") bubble.applySize(Prefs.size(this))
        if (key == "alpha") bubble.applyAlpha(Prefs.alpha(this))
        if (key == "apps") {
            fgPkg = null
            lastEvents = 0L
        }
        if (key != "x" && key != "y") restartPoller()
    }

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            if (i.action == Intent.ACTION_SCREEN_OFF) {
                handler.removeCallbacks(poller)
                hideBubble()
            } else {
                restartPoller()
            }
        }
    }

    private val poller = object : Runnable {
        override fun run() {
            tick()
            handler.postDelayed(this, INTERVAL)
        }
    }

    private fun restartPoller() {
        handler.removeCallbacks(poller)
        if ((getSystemService(Context.POWER_SERVICE) as PowerManager).isInteractive) handler.post(poller)
    }

    override fun onCreate() {
        super.onCreate()
        bubble = FloatingBubble(this)

        val nm = getSystemService(NotificationManager::class.java)
        val channel = NotificationChannel(CH, "Служебное", NotificationManager.IMPORTANCE_MIN)
        channel.setShowBadge(false)
        nm.createNotificationChannel(channel)

        val n = Notification.Builder(this, CH)
            .setSmallIcon(R.drawable.ic_thermo)
            .setContentTitle("BatteryGuard")
            .setContentText("Мониторинг температуры")
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }

        registerReceiver(screenReceiver, IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_SCREEN_ON)
        })
        Prefs.sp(this).registerOnSharedPreferenceChangeListener(prefListener)
        restartPoller()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int) = START_STICKY

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        try {
            unregisterReceiver(screenReceiver)
        } catch (_: Exception) {
        }
        Prefs.sp(this).unregisterOnSharedPreferenceChangeListener(prefListener)
        bubble.hide()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    @Suppress("DEPRECATION")
    private fun pollForeground() {
        if (Prefs.apps(this).isEmpty() || !Perms.usage(this)) {
            fgPkg = null
            lastEvents = 0L
            return
        }
        val usm = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val now = System.currentTimeMillis()
        val from = if (lastEvents == 0L) now - 3_600_000L else lastEvents
        val events = usm.queryEvents(from, now)
        val e = UsageEvents.Event()
        while (events.hasNextEvent()) {
            events.getNextEvent(e)
            when (e.eventType) {
                UsageEvents.Event.MOVE_TO_FOREGROUND -> fgPkg = e.packageName
                UsageEvents.Event.MOVE_TO_BACKGROUND -> if (fgPkg == e.packageName) fgPkg = null
            }
        }
        lastEvents = now - 2000L
    }

    private fun hideBubble() {
        if (visible) bubble.hide()
        visible = false
        lastB = null
        lastC = null
        cpuShown = null
        cpuPending = false
    }

    private fun filterCpu(v: Float?): Float? {
        if (v == null) return cpuShown
        val prev = cpuShown
        if (prev != null && v - prev > JUMP && !cpuPending) {
            cpuPending = true
            return prev
        }
        cpuPending = false
        cpuShown = v
        return v
    }

    private fun tick() {
        pollForeground()
        val pkg = fgPkg
        val inApp = pkg != null && pkg in Prefs.apps(this)
        if (!inApp || !Perms.overlay(this)) {
            hideBubble()
            return
        }

        val mode = Prefs.mode(this)
        val wantBatt = mode != 1
        val wantCpu = mode != 0

        var batt: Float? = null
        if (wantBatt) {
            val i = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val raw = i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE) ?: Int.MIN_VALUE
            if (raw != Int.MIN_VALUE) batt = raw / 10f
        }
        val cpu = if (wantCpu) filterCpu(CpuTemp.read()) else null

        val alert = (batt != null && batt >= Prefs.threshold(this)) ||
            (cpu != null && cpu >= Prefs.cpuThreshold(this))

        val b = if (wantBatt) (if (batt != null) String.format(java.util.Locale.US, "%.1f°", batt) else "—") else null
        val c = if (wantCpu) (if (cpu != null) String.format(java.util.Locale.US, "%d°", Math.round(cpu)) else "—") else null

        if (!visible || b != lastB || c != lastC || alert != lastAlert) {
            bubble.show(b, c, alert)
            visible = true
            lastB = b
            lastC = c
            lastAlert = alert
        }
    }

    companion object {
        private const val CH = "service"
        private const val INTERVAL = 3000L
        private const val JUMP = 8f
    }
}
