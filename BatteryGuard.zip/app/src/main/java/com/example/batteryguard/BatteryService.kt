package com.example.batteryguard

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager

class BatteryService : Service() {

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var bubble: FloatingBubble
    private var temp = 0f
    private var fgPkg: String? = null
    private var lastEvents = 0L

    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        if (key == "size") bubble.applySize(Prefs.size(this))
        if (key == "apps") {
            fgPkg = null
            lastEvents = 0L
        }
        refresh()
    }

    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            temp = i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10f
            refresh()
        }
    }

    private val poller = object : Runnable {
        override fun run() {
            pollForeground()
            refresh()
            val apps = Prefs.apps(this@BatteryService)
            handler.postDelayed(this, if (apps.isEmpty()) 5000L else 1000L)
        }
    }

    override fun onCreate() {
        super.onCreate()
        bubble = FloatingBubble(this)

        val nm = getSystemService(NotificationManager::class.java)
        val channel = NotificationChannel(CH, "Служебное", NotificationManager.IMPORTANCE_MIN)
        channel.setShowBadge(false)
        nm.createNotificationChannel(channel)

        val n = Notification.Builder(this, CH)
            .setSmallIcon(R.drawable.ic_thermo)
            .setContentTitle("BatteryGuard")
            .setContentText("Мониторинг температуры")
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }

        registerReceiver(batteryReceiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        Prefs.sp(this).registerOnSharedPreferenceChangeListener(prefListener)
        handler.post(poller)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int) = START_STICKY

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        try {
            unregisterReceiver(batteryReceiver)
        } catch (_: Exception) {
        }
        Prefs.sp(this).unregisterOnSharedPreferenceChangeListener(prefListener)
        bubble.hide()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    @Suppress("DEPRECATION")
    private fun pollForeground() {
        if (Prefs.apps(this).isEmpty() || !Perms.usage(this)) {
            fgPkg = null
            lastEvents = 0L
            return
        }
        val usm = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val now = System.currentTimeMillis()
        val from = if (lastEvents == 0L) now - 3_600_000L else lastEvents
        val events = usm.queryEvents(from, now)
        val e = UsageEvents.Event()
        while (events.hasNextEvent()) {
            events.getNextEvent(e)
            when (e.eventType) {
                UsageEvents.Event.MOVE_TO_FOREGROUND -> fgPkg = e.packageName
                UsageEvents.Event.MOVE_TO_BACKGROUND -> if (fgPkg == e.packageName) fgPkg = null
            }
        }
        lastEvents = now - 2000L
    }

    private fun refresh() {
        val alert = temp >= Prefs.threshold(this)
        val pkg = fgPkg
        val inApp = pkg != null && pkg in Prefs.apps(this)
        val interactive = (getSystemService(Context.POWER_SERVICE) as PowerManager).isInteractive
        if (Perms.overlay(this) && interactive && (alert || inApp)) {
            bubble.show(temp, alert)
        } else {
            bubble.hide()
        }
    }

    companion object {
        private const val CH = "service"
    }
}
