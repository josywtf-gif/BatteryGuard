package com.example.batteryguard

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

class FloatingBubble(private val ctx: Context) {

    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager

    private val icon = ImageView(ctx).apply {
        setImageResource(R.drawable.ic_thermo)
        setColorFilter(Color.WHITE)
    }

    private val label = TextView(ctx).apply {
        setTextColor(Color.WHITE)
        typeface = Typeface.DEFAULT_BOLD
    }

    private val bg = GradientDrawable().apply {
        cornerRadius = 1000f
        setColor(COLOR_NORMAL)
    }

    private val root = LinearLayout(ctx).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        background = bg
        addView(icon)
        addView(label)
    }

    private val lp = WindowManager.LayoutParams(
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
        PixelFormat.TRANSLUCENT
    ).apply {
        gravity = Gravity.TOP or Gravity.START
        x = if (Prefs.posX(ctx) >= 0) Prefs.posX(ctx) else px(16)
        y = if (Prefs.posY(ctx) >= 0) Prefs.posY(ctx) else px(120)
    }

    private var shown = false
    private var dx = 0f
    private var dy = 0f

    init {
        applySize(Prefs.size(ctx))
        root.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    dx = lp.x - e.rawX
                    dy = lp.y - e.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = (e.rawX + dx).toInt()
                    lp.y = (e.rawY + dy).toInt()
                    if (shown) wm.updateViewLayout(root, lp)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    Prefs.setPos(ctx, lp.x, lp.y)
                    true
                }
                else -> false
            }
        }
    }

    private fun px(dp: Int): Int = (dp * ctx.resources.displayMetrics.density).toInt()

    fun applySize(dp: Int) {
        val s = px(dp)
        icon.layoutParams = LinearLayout.LayoutParams(s, s)
        label.setTextSize(TypedValue.COMPLEX_UNIT_PX, s * 0.42f)
        label.layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { marginStart = s / 8 }
        root.setPadding(s / 4, s / 8, s / 3, s / 8)
        if (shown) {
            try {
                wm.updateViewLayout(root, lp)
            } catch (_: Exception) {
            }
        }
    }

    fun show(temp: Float, alert: Boolean) {
        label.text = String.format("%.1f°", temp)
        bg.setColor(if (alert) COLOR_ALERT else COLOR_NORMAL)
        if (!shown) {
            try {
                wm.addView(root, lp)
                shown = true
            } catch (_: Exception) {
            }
        }
    }

    fun hide() {
        if (shown) {
            try {
                wm.removeView(root)
            } catch (_: Exception) {
            }
            shown = false
        }
    }

    companion object {
        private val COLOR_NORMAL = Color.argb(230, 38, 50, 56)
        private val COLOR_ALERT = Color.argb(240, 211, 47, 47)
    }
}
