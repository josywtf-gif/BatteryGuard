package com.example.batteryguard

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Paint
import android.graphics.Typeface
import android.text.TextUtils
import android.graphics.drawable.GradientDrawable
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

class FloatingBubble(private val ctx: Context, type: Int = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY) {
    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val root = LinearLayout(ctx).apply { orientation=LinearLayout.VERTICAL; gravity=Gravity.START; background=GradientDrawable().apply { cornerRadius=px(18).toFloat(); setColor(Color.argb(238,25,32,46)) }; setPadding(px(12),px(8),px(14),px(8)) }
    private val rows = LinkedHashMap<String, Pair<ImageView,TextView>>()
    private val lp = WindowManager.LayoutParams(px(236),px(198),type,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,PixelFormat.TRANSLUCENT).apply { gravity=Gravity.TOP or Gravity.START; x=if(Prefs.posX(ctx)>=0) Prefs.posX(ctx) else px(16); y=if(Prefs.posY(ctx)>=0) Prefs.posY(ctx) else px(120) }
    private var shown=false; private var dx=0f; private var dy=0f
    private var textSizeSp = 14f
    private var rowHeightPx = px(34)
    private var configuredKeys: List<String> = emptyList()
    init {
        applySize(Prefs.size(ctx), Prefs.metrics(ctx).filter { it != "voltage" }); applyAlpha(Prefs.alpha(ctx))
        root.setOnTouchListener { _,e -> when(e.action) { MotionEvent.ACTION_DOWN -> { dx=lp.x-e.rawX; dy=lp.y-e.rawY; true }; MotionEvent.ACTION_MOVE -> { lp.x=(e.rawX+dx).toInt(); lp.y=(e.rawY+dy).toInt(); if(shown) try { wm.updateViewLayout(root,lp) } catch(_:Exception) {}; true }; MotionEvent.ACTION_UP -> { Prefs.setPos(ctx,lp.x,lp.y); true }; else -> false } }
    }
    private fun px(dp:Int)= (dp*ctx.resources.displayMetrics.density).toInt()
    private fun iconRes(key: String): Int = when (key) {
        "cpu_temp" -> R.drawable.ic_cpu_temp
        "battery_temp" -> R.drawable.ic_battery_temp
        "ram" -> R.drawable.ic_ram
        "time" -> R.drawable.ic_clock
        "battery" -> R.drawable.ic_charge
        else -> R.drawable.ic_thermo
    }

    private fun iconColor(key: String): Int = when (key) {
        "cpu_temp" -> 0xFFFF8A65.toInt()
        "battery_temp" -> 0xFFFFB74D.toInt()
        "ram" -> 0xFF80CBC4.toInt()
        "time" -> 0xFFFFD166.toInt()
        "battery" -> 0xFF81C784.toInt()
        else -> 0xFF90CAF9.toInt()
    }

    private fun row(key:String): Pair<ImageView,TextView> {
        val symbol = ImageView(ctx).apply {
            setImageResource(iconRes(key))
            setColorFilter(iconColor(key))
            scaleType = ImageView.ScaleType.FIT_CENTER
            layoutParams = LinearLayout.LayoutParams(px(28), px(28))
            contentDescription = key
        }
        val tv=TextView(ctx).apply {
            setTextColor(Color.WHITE)
            typeface=Typeface.DEFAULT_BOLD
            setTextSize(TypedValue.COMPLEX_UNIT_SP,textSizeSp)
            setPadding(px(7),0,0,0)
            maxLines=1
            ellipsize=TextUtils.TruncateAt.END
            includeFontPadding=false
            gravity=Gravity.CENTER_VERTICAL
        }
        root.addView(LinearLayout(ctx).apply {
            orientation=LinearLayout.HORIZONTAL
            gravity=Gravity.CENTER_VERTICAL
            layoutParams=LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,rowHeightPx)
            addView(symbol,LinearLayout.LayoutParams(px(28),px(28)))
            addView(tv,LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.MATCH_PARENT,1f))
        })
        return symbol to tv
    }
    /**
     * Размер окна зависит только от настроек отображения (размер шрифта и выбранные
     * показатели), а не от текущих значений датчиков. Поэтому цифры могут меняться
     * хоть каждую секунду, но габариты окна остаются неизменными.
     */
    fun applySize(dp:Int, metricKeys: List<String> = configuredKeys) {
        val keys = metricKeys.distinct()
        val oldWidth = lp.width
        val oldHeight = lp.height
        val sizeChanged = textSizeSp != (dp * 0.30f).coerceIn(12f, 24f)
        val keysChanged = configuredKeys != keys
        textSizeSp=(dp*0.30f).coerceIn(12f,24f)
        rowHeightPx=px(maxOf(34, (textSizeSp*1.9f).toInt()))

        val horizontalPaddingDp = maxOf(8, dp / 4)
        val verticalPadding = px(maxOf(8, dp / 8))
        root.setPadding(px(horizontalPaddingDp), verticalPadding, px(horizontalPaddingDp), verticalPadding)

        val samples = mapOf(
            "cpu_temp" to "999.9 °C",
            "battery_temp" to "999.9 °C",
            "ram" to "99999 / 99999 MB",
            "time" to "23:59",
            "battery" to if (Prefs.voltageDetailsEnabled(ctx)) "100% · 5.00 В · −99999 мА" else "100%"
        )
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            typeface = Typeface.DEFAULT_BOLD
            textSize = textSizeSp * ctx.resources.displayMetrics.scaledDensity
        }
        val widestText = keys.mapNotNull { samples[it] }.maxOfOrNull { paint.measureText(it) } ?: paint.measureText("н/д")
        val iconAndGap = px(28 + 7)
        val safety = px(12)
        // Небольшая прибавка на каждый активный пункт делает ширину адаптивной
        // при изменении состава списка, даже если новый пункт короче самого длинного.
        val selectionAllowance = px((keys.size - 1).coerceAtLeast(0) * 2)
        val desiredWidth = (widestText + iconAndGap + px(horizontalPaddingDp * 2) + safety + selectionAllowance).toInt()
        val screenWidth = ctx.resources.displayMetrics.widthPixels
        lp.width = desiredWidth.coerceIn(px(112), (screenWidth - px(24)).coerceAtLeast(px(112)))
        lp.height = (keys.size.coerceAtLeast(1) * rowHeightPx) + verticalPadding * 2
        configuredKeys = keys

        if (sizeChanged || keysChanged) {
            rows.values.forEach { it.second.setTextSize(TypedValue.COMPLEX_UNIT_SP,textSizeSp) }
        }
        if(shown && (oldWidth != lp.width || oldHeight != lp.height)) {
            try { wm.updateViewLayout(root,lp) } catch(_:Exception) {}
        }
    }
    fun applyAlpha(percent:Int) { root.alpha=percent.coerceIn(30,100)/100f }
    fun show(values:Map<String,String>) {
        // Пересчитываем габариты только по конфигурации показателей и размеру текста.
        // Сами показания датчиков никогда не участвуют в выборе ширины/высоты.
        applySize(Prefs.size(ctx), values.keys.toList())
        root.removeAllViews(); rows.clear()
        values.forEach { (key,value) -> val pair=row(key); pair.second.text=value; rows[key]=pair }
        if(!shown) try { wm.addView(root,lp); shown=true } catch(_:Exception) {}
        else root.requestLayout()
    }
    fun hide() { if(shown) try { wm.removeView(root) } catch(_:Exception) {}; shown=false }
}
