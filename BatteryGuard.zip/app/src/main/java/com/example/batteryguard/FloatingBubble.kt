package com.example.batteryguard

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

class FloatingBubble(
    private val ctx: Context,
    private val type: Int = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
) {

    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager

    private fun makeIcon(res: Int, tint: Int) = ImageView(ctx).apply {
        setImageResource(res)
        setColorFilter(tint)
    }

    private fun makeLabel() = TextView(ctx).apply {
        setTextColor(Color.WHITE)
        typeface = Typeface.DEFAULT_BOLD
    }

    private fun makeItem(icon: View, label: View) = LinearLayout(ctx).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        addView(icon)
        addView(label)
    }

    private val iconBatt = makeIcon(R.drawable.ic_battery, COLOR_BATT)
    private val textBatt = makeLabel()
    private val iconCpu = makeIcon(R.drawable.ic_cpu, COLOR_CPU)
    private val textCpu = makeLabel()
    private val itemBatt = makeItem(iconBatt, textBatt)
    private val itemCpu = makeItem(iconCpu, textCpu)

    private val bg = GradientDrawable().apply {
        cornerRadius = 1000f
        setColor(COLOR_NORMAL)
    }

    private val root = LinearLayout(ctx).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        background = bg
        addView(itemBatt)
        addView(itemCpu)
    }

    private val lp = WindowManager.LayoutParams(
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.WRAP_CONTENT,
        type,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
        PixelFormat.TRANSLUCENT
    ).apply {
        gravity = Gravity.TOP or Gravity.START
        x = if (Prefs.posX(ctx) >= 0) Prefs.posX(ctx) else px(16)
        y = if (Prefs.posY(ctx) >= 0) Prefs.posY(ctx) else px(120)
    }

    private var shown = false
    private var gap = 0
    private var dx = 0f
    private var dy = 0f

    init {
        applySize(Prefs.size(ctx))
        applyAlpha(Prefs.alpha(ctx))
        root.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    dx = lp.x - e.rawX
                    dy = lp.y - e.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = (e.rawX + dx).toInt()
                    lp.y = (e.rawY + dy).toInt()
                    if (shown) wm.updateViewLayout(root, lp)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    Prefs.setPos(ctx, lp.x, lp.y)
                    true
                }
                else -> false
            }
        }
    }

    private fun px(dp: Int): Int = (dp * ctx.resources.displayMetrics.density).toInt()

    private fun wrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.WRAP_CONTENT,
        ViewGroup.LayoutParams.WRAP_CONTENT
    )

    fun applySize(dp: Int) {
        val s = px(dp)
        val iconSize = (s * 0.7f).toInt()
        iconBatt.layoutParams = LinearLayout.LayoutParams(iconSize, iconSize)
        iconCpu.layoutParams = LinearLayout.LayoutParams(iconSize, iconSize)
        for (t in listOf(textBatt, textCpu)) {
            t.setTextSize(TypedValue.COMPLEX_UNIT_PX, s * 0.4f)
            t.layoutParams = wrap().apply { marginStart = s / 10 }
        }
        itemBatt.layoutParams = wrap()
        gap = s / 3
        itemCpu.layoutParams = wrap().apply { marginStart = gap }
        root.setPadding(s / 3, s / 6, s / 3, s / 6)
        if (shown) {
            try {
                wm.updateViewLayout(root, lp)
            } catch (_: Exception) {
            }
        }
    }

    fun applyAlpha(percent: Int) {
        root.alpha = percent.coerceIn(10, 100) / 100f
    }

    fun show(battText: String?, cpuText: String?, alert: Boolean): Boolean {
        itemBatt.visibility = if (battText != null) View.VISIBLE else View.GONE
        itemCpu.visibility = if (cpuText != null) View.VISIBLE else View.GONE
        textBatt.text = battText ?: ""
        textCpu.text = cpuText ?: ""
        (itemCpu.layoutParams as LinearLayout.LayoutParams).marginStart = if (battText != null) gap else 0
        bg.setColor(if (alert) COLOR_ALERT else COLOR_NORMAL)
        if (!shown || !root.isAttachedToWindow) {
            shown = false
            try {
                wm.addView(root, lp)
                shown = root.isAttachedToWindow
            } catch (_: Exception) {
                shown = false
            }
        } else {
            try {
                wm.updateViewLayout(root, lp)
                root.requestLayout()
            } catch (_: Exception) {
                shown = false
            }
        }
        return shown
    }

    fun hide() {
        if (shown) {
            try {
                wm.removeView(root)
            } catch (_: Exception) {
            }
            shown = false
        }
    }

    companion object {
        private val COLOR_NORMAL = Color.argb(235, 30, 41, 59)
        private val COLOR_ALERT = Color.argb(245, 198, 40, 40)
        private val COLOR_BATT = Color.parseColor("#81C784")
        private val COLOR_CPU = Color.parseColor("#64B5F6")
    }
}
