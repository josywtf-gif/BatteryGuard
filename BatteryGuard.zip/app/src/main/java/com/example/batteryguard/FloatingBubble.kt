package com.example.batteryguard

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView

class FloatingBubble(private val ctx: Context, type: Int = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY) {
    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val root = LinearLayout(ctx).apply { orientation=LinearLayout.VERTICAL; gravity=Gravity.START; background=GradientDrawable().apply { cornerRadius=px(18).toFloat(); setColor(Color.argb(238,25,32,46)) }; setPadding(px(12),px(8),px(14),px(8)) }
    private val rows = LinkedHashMap<String, Pair<TextView,TextView>>()
    private val lp = WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.WRAP_CONTENT,type,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,PixelFormat.TRANSLUCENT).apply { gravity=Gravity.TOP or Gravity.START; x=if(Prefs.posX(ctx)>=0) Prefs.posX(ctx) else px(16); y=if(Prefs.posY(ctx)>=0) Prefs.posY(ctx) else px(120) }
    private var shown=false; private var dx=0f; private var dy=0f
    init {
        applySize(Prefs.size(ctx)); applyAlpha(Prefs.alpha(ctx))
        root.setOnTouchListener { _,e -> when(e.action) { MotionEvent.ACTION_DOWN -> { dx=lp.x-e.rawX; dy=lp.y-e.rawY; true }; MotionEvent.ACTION_MOVE -> { lp.x=(e.rawX+dx).toInt(); lp.y=(e.rawY+dy).toInt(); if(shown) try { wm.updateViewLayout(root,lp) } catch(_:Exception) {}; true }; MotionEvent.ACTION_UP -> { Prefs.setPos(ctx,lp.x,lp.y); true }; else -> false } }
    }
    private fun px(dp:Int)= (dp*ctx.resources.displayMetrics.density).toInt()
    private fun icon(key:String): String = when(key) { "cpu"->"◉"; "temp"->"♨"; "gpu"->"▦"; "ram"->"▤"; "time"->"◷"; "battery"->"▰"; else->"•" }
    private fun color(key:String)=when(key) { "cpu"->0xFF64B5F6.toInt(); "temp"->0xFFFF8A65.toInt(); "gpu"->0xFFBA9CFF.toInt(); "ram"->0xFF80CBC4.toInt(); "time"->0xFFFFD166.toInt(); else->0xFF81C784.toInt() }
    private fun row(key:String): Pair<TextView,TextView> {
        val symbol=TextView(ctx).apply { text=icon(key); setTextColor(color(key)); setTextSize(TypedValue.COMPLEX_UNIT_SP,17f); gravity=Gravity.CENTER; layoutParams=LinearLayout.LayoutParams(px(25),px(27)) }
        val tv=TextView(ctx).apply { setTextColor(Color.WHITE); typeface=Typeface.DEFAULT_BOLD; setTextSize(TypedValue.COMPLEX_UNIT_SP,textSizeSp); setPadding(px(7),px(3),0,px(3)) }
        root.addView(LinearLayout(ctx).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL; addView(symbol); addView(tv,LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,ViewGroup.LayoutParams.WRAP_CONTENT)) })
        return symbol to tv
    }
    fun applySize(dp:Int) { textSizeSp=(dp*0.30f).coerceIn(12f,24f); root.setPadding(px(dp/4),px(dp/8),px(dp/4),px(dp/8)); rows.values.forEach { it.second.setTextSize(TypedValue.COMPLEX_UNIT_SP,(dp*0.30f).coerceIn(12f,24f)) }; if(shown) try { wm.updateViewLayout(root,lp) } catch(_:Exception) {} }
    fun applyAlpha(percent:Int) { root.alpha=percent.coerceIn(30,100)/100f }
    fun show(values:Map<String,String>) {
        root.removeAllViews(); rows.clear()
        values.forEach { (key,value) -> val pair=row(key); pair.second.text=value; rows[key]=pair }
        if(!shown) try { wm.addView(root,lp); shown=true } catch(_:Exception) {} else root.requestLayout()
    }
    fun hide() { if(shown) try { wm.removeView(root) } catch(_:Exception) {}; shown=false }
}
