package com.example.batteryguard

import android.app.AppOpsManager
import android.content.Context
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.os.PowerManager
import android.os.Process
import android.provider.Settings

object Prefs {
    const val FILE = "batteryguard"

    fun sp(c: Context): SharedPreferences = c.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun isEnabled(c: Context) = sp(c).getBoolean("enabled", false)
    fun setEnabled(c: Context, v: Boolean) = sp(c).edit().putBoolean("enabled", v).apply()

    fun threshold(c: Context) = sp(c).getFloat("threshold", 44f)
    fun setThreshold(c: Context, v: Float) = sp(c).edit().putFloat("threshold", v).apply()

    fun size(c: Context) = sp(c).getInt("size", 56)
    fun setSize(c: Context, v: Int) = sp(c).edit().putInt("size", v).apply()

    fun apps(c: Context): Set<String> = HashSet(sp(c).getStringSet("apps", emptySet()) ?: emptySet())
    fun setApps(c: Context, v: Set<String>) = sp(c).edit().putStringSet("apps", HashSet(v)).apply()

    fun posX(c: Context) = sp(c).getInt("x", -1)
    fun posY(c: Context) = sp(c).getInt("y", -1)
    fun setPos(c: Context, x: Int, y: Int) = sp(c).edit().putInt("x", x).putInt("y", y).apply()

    fun asked(c: Context, key: String) = sp(c).getBoolean("asked_$key", false)
    fun setAsked(c: Context, key: String) = sp(c).edit().putBoolean("asked_$key", true).apply()
}

object Perms {
    fun overlay(c: Context) = Settings.canDrawOverlays(c)

    @Suppress("DEPRECATION")
    fun usage(c: Context): Boolean {
        val ops = c.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.packageName)
        return if (mode == AppOpsManager.MODE_DEFAULT) {
            c.checkCallingOrSelfPermission(android.Manifest.permission.PACKAGE_USAGE_STATS) ==
                PackageManager.PERMISSION_GRANTED
        } else {
            mode == AppOpsManager.MODE_ALLOWED
        }
    }

    fun ignoringBattery(c: Context): Boolean =
        (c.getSystemService(Context.POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(c.packageName)
}
