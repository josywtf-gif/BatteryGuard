package com.example.batteryguard

import android.content.Context
import android.content.SharedPreferences
import android.provider.Settings

object Prefs {
    const val FILE = "batteryguard"
    const val METRICS = "metrics_order"
    const val DEFAULT_METRICS = "cpu,temp,gpu,ram,time,battery"
    fun sp(c: Context): SharedPreferences = c.getSharedPreferences(FILE, Context.MODE_PRIVATE)
    fun isEnabled(c: Context) = sp(c).getBoolean("enabled", false)
    fun setEnabled(c: Context, v: Boolean) = sp(c).edit().putBoolean("enabled", v).apply()
    fun metrics(c: Context): MutableList<String> = sp(c).getString(METRICS, DEFAULT_METRICS)!!.split(',').filter { it in ALL_METRICS }.distinct().toMutableList()
    fun setMetrics(c: Context, v: List<String>) = sp(c).edit().putString(METRICS, v.filter { it in ALL_METRICS }.distinct().joinToString(",")).apply()
    fun size(c: Context) = sp(c).getInt("size", 48)
    fun setSize(c: Context, v: Int) = sp(c).edit().putInt("size", v).apply()
    fun alpha(c: Context) = sp(c).getInt("alpha", 90)
    fun setAlpha(c: Context, v: Int) = sp(c).edit().putInt("alpha", v).apply()
    fun posX(c: Context) = sp(c).getInt("x", -1)
    fun posY(c: Context) = sp(c).getInt("y", -1)
    fun setPos(c: Context, x: Int, y: Int) = sp(c).edit().putInt("x", x).putInt("y", y).apply()
    fun overlay(c: Context) = Settings.canDrawOverlays(c)
    val ALL_METRICS = listOf("cpu", "temp", "gpu", "ram", "time", "battery")
}
