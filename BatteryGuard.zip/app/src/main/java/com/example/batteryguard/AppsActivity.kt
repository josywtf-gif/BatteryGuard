package com.example.batteryguard

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.doAfterTextChanged
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText

class AppsActivity : AppCompatActivity() {

    data class Item(val pkg: String, val label: String)

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val icon: ImageView = v.findViewById(R.id.icon)
        val name: TextView = v.findViewById(R.id.name)
        val check: CheckBox = v.findViewById(R.id.check)
    }

    private val all = mutableListOf<Item>()
    private val shown = mutableListOf<Item>()
    private lateinit var selected: MutableSet<String>
    private lateinit var adapter: AppAdapter
    private lateinit var cardUsage: View

    private inner class AppAdapter : RecyclerView.Adapter<VH>() {
        override fun getItemCount() = shown.size

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
            VH(LayoutInflater.from(parent.context).inflate(R.layout.item_app, parent, false))

        override fun onBindViewHolder(h: VH, position: Int) {
            val item = shown[position]
            h.name.text = item.label
            try {
                h.icon.setImageDrawable(packageManager.getApplicationIcon(item.pkg))
            } catch (_: Exception) {
                h.icon.setImageDrawable(null)
            }
            h.check.isChecked = item.pkg in selected
            h.itemView.setOnClickListener {
                if (!selected.remove(item.pkg)) selected.add(item.pkg)
                Prefs.setApps(this@AppsActivity, selected)
                h.check.isChecked = item.pkg in selected
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_apps)

        selected = Prefs.apps(this).toMutableSet()
        cardUsage = findViewById(R.id.cardUsage)
        findViewById<MaterialButton>(R.id.btnUsage).setOnClickListener {
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
        }

        adapter = AppAdapter()
        val rv: RecyclerView = findViewById(R.id.rv)
        rv.layoutManager = LinearLayoutManager(this)
        rv.adapter = adapter

        findViewById<TextInputEditText>(R.id.search).doAfterTextChanged { filter(it?.toString() ?: "") }

        Thread {
            val pm = packageManager
            val list = pm.getInstalledApplications(0)
                .filter { it.packageName != packageName && pm.getLaunchIntentForPackage(it.packageName) != null }
                .map { Item(it.packageName, it.loadLabel(pm).toString()) }
                .sortedWith(compareByDescending<Item> { it.pkg in selected }.thenBy { it.label.lowercase() })
            runOnUiThread {
                all.clear()
                all.addAll(list)
                filter("")
            }
        }.start()
    }

    override fun onResume() {
        super.onResume()
        cardUsage.visibility = View.GONE
    }

    private fun filter(q: String) {
        shown.clear()
        shown.addAll(all.filter { q.isBlank() || it.label.contains(q, ignoreCase = true) })
        adapter.notifyDataSetChanged()
    }
}
