package com.example.batteryguard

/** This class is launched by Shizuku as Android's shell UID (2000), not as root. */
class FpsShellUserService : IFpsShellService.Stub() {
    override fun exec(command: String): String {
        return try {
            val process = ProcessBuilder("sh", "-c", command)
                .redirectErrorStream(true)
                .start()
            val output = process.inputStream.bufferedReader().use { it.readText() }
            if (!process.waitFor(4, java.util.concurrent.TimeUnit.SECONDS)) {
                process.destroyForcibly()
                ""
            } else if (process.exitValue() == 0) output else ""
        } catch (_: Throwable) { "" }
    }
}
