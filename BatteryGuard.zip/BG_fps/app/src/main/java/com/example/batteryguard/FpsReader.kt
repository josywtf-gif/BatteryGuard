package com.example.batteryguard

import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.content.ServiceConnection
import rikka.shizuku.Shizuku
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/**
 * Reads SurfaceFlinger presented-frame timestamps through Shizuku UserService running as
 * Android shell UID (ADB=2000). This does not use root. Availability is OEM/Android dependent.
 */
object FpsReader {
    @Volatile var latest: String = "н/д"
        private set
    @Volatile private var running = false
    @Volatile private var shell: IFpsShellService? = null
    @Volatile private var bindRequested = false
    private val worker = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())
    private var appContext: Context? = null
    private lateinit var userServiceArgs: Shizuku.UserServiceArgs

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
            shell = IFpsShellService.Stub.asInterface(service)
            bindRequested = false
        }
        override fun onServiceDisconnected(name: ComponentName?) {
            shell = null
            bindRequested = false
        }
    }

    fun hasShizukuPermission(): Boolean = try {
        Shizuku.pingBinder() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (_: Throwable) { false }

    fun shizukuRunning(): Boolean = try { Shizuku.pingBinder() } catch (_: Throwable) { false }

    @Synchronized
    fun connect(context: Context): Boolean {
        appContext = context.applicationContext
        if (!hasShizukuPermission()) return false
        if (shell != null) return true
        if (bindRequested) return false
        return try {
            userServiceArgs = Shizuku.UserServiceArgs(
                ComponentName(context, FpsShellUserService::class.java)
            ).daemon(true).processNameSuffix("fps_shell").tag("BatteryGuardFpsShell").version(1)
            bindRequested = true
            Shizuku.bindUserService(userServiceArgs, connection)
            false // connection is asynchronous
        } catch (_: Throwable) {
            bindRequested = false
            false
        }
    }

    fun requestUpdate(context: Context, onResult: ((String) -> Unit)? = null) {
        if (running) return
        if (!hasShizukuPermission()) {
            latest = "н/д"
            onResult?.let { main.post { it(latest) } }
            return
        }
        if (shell == null) {
            connect(context)
            latest = "н/д"
            onResult?.let { main.post { it(latest) } }
            return
        }
        running = true
        worker.execute {
            val result = try { readGameFps()?.let { "$it FPS" } ?: "н/д" } catch (_: Throwable) { "н/д" }
            latest = result
            running = false
            onResult?.let { main.post { it(result) } }
        }
    }

    private fun command(command: String): String? = try {
        shell?.exec(command)?.takeIf { it.isNotBlank() }
    } catch (_: Throwable) { null }

    private fun readGameFps(): Int? {
        val activityDump = command("dumpsys activity activities | grep -E 'mResumedActivity|topResumedActivity' | tail -n 2") ?: return null
        val packageName = Regex("([A-Za-z0-9_]+(?:\\.[A-Za-z0-9_]+)+)/")
            .findAll(activityDump).lastOrNull()?.groupValues?.getOrNull(1) ?: return null
        val layerDump = command("dumpsys SurfaceFlinger --list") ?: return null
        val layers = layerDump.lineSequence().map { it.trim() }
            .filter { it.contains(packageName) && (it.contains("SurfaceView", true) || it.contains("BLAST", true) || it.contains("BufferQueue", true)) }
            .take(5).toList()
        if (layers.isEmpty()) return null

        val nowNs = System.nanoTime()
        var best: Int? = null
        for (layer in layers) {
            val safeLayer = "'" + layer.replace("'", "'\\''") + "'"
            val dump = command("dumpsys SurfaceFlinger --latency $safeLayer") ?: continue
            val timestamps = dump.lineSequence().drop(1).mapNotNull { line ->
                val cols = line.trim().split(Regex("\\s+")).mapNotNull { it.toLongOrNull() }
                if (cols.size < 2) null else {
                    // SurfaceFlinger legacy latency columns: desiredPresent, actualPresent, frameReady (ns).
                    val actual = cols[1]
                    if (actual > 0L) actual else cols[0].takeIf { it > 0L }
                }
            }.filter { it <= nowNs && nowNs - it <= 2_000_000_000L }.distinct().toList()
            if (timestamps.size >= 2) {
                val span = (timestamps.maxOrNull()!! - timestamps.minOrNull()!!).coerceAtLeast(1L)
                val fps = (((timestamps.size - 1) * 1_000_000_000.0) / span).toInt().coerceIn(1, 360)
                if (best == null || fps > best!!) best = fps
            }
        }
        return best
    }
}
