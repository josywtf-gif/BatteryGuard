package com.example.batteryguard;

interface IFpsShellService {
    String exec(String command);
}
