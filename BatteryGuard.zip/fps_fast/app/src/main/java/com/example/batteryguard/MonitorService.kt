package com.example.batteryguard

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.app.ActivityManager
import android.app.AlarmManager
import android.app.PendingIntent
import android.os.SystemClock
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

class MonitorService : Service() {
    private val handler = Handler(Looper.getMainLooper())
    private val metricsWorker = Executors.newSingleThreadExecutor()
    private val refreshPending = AtomicBoolean(false)
    private val cachedMetrics = LinkedHashMap<String, String>()
    private val lastMetricRead = HashMap<String, Long>()
    private var bubble: FloatingBubble? = null
    private lateinit var gameStore: GameStatsStore
    private var activeGamePackage: String? = null
    private var activeGameSessionId: Long? = null
    private var lastTrackedGameSeenAt = 0L
    private val update = object : Runnable {
        override fun run() {
            if (!Prefs.isEnabled(this@MonitorService)) { stopSelf(); return }
            trackGameSession()
            refreshOverlay()
            // Game-session sampling is independent of OSD checkboxes.
            val interval = if (GameTracking.selected(this@MonitorService).isNotEmpty() || Prefs.fpsMonitoringEnabled(this@MonitorService)) 1000L else 3000L
            handler.postDelayed(this, interval)
        }
    }
    override fun onCreate() {
        super.onCreate()
        gameStore = GameStatsStore(this)
        gameStore.closeAbandonedSessions()
        createChannel(); startForeground(NOTIFICATION_ID, notification())
        if (Prefs.overlay(this)) bubble = FloatingBubble(this, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY)
        handler.post(update)
    }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int { if (intent?.action == ACTION_STOP) { Prefs.setEnabled(this, false); stopSelf(); return START_NOT_STICKY }; if (!Prefs.isEnabled(this)) { stopSelf(); return START_NOT_STICKY }; if (bubble == null && Prefs.overlay(this)) bubble = FloatingBubble(this, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY); refreshOverlay(); return START_STICKY }
    override fun onBind(intent: Intent?): IBinder? = null
    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        finishActiveGameSession()
        FpsReader.stopCapture()
        metricsWorker.shutdownNow()
        bubble?.hide()
        bubble = null
        // Не сбрасываем пользовательский флаг при системном уничтожении процесса.
        // Явное выключение уже устанавливает false в ACTION_STOP/переключателе.
        if (Prefs.isEnabled(this)) scheduleRestart()
        stopForeground(STOP_FOREGROUND_REMOVE)
        super.onDestroy()
    }
    private fun trackGameSession() {
        val selected = GameTracking.selected(this)
        if (selected.isEmpty() || !GameTracking.hasUsageAccess(this)) {
            finishActiveGameSession()
            if (selected.isNotEmpty()) FpsReader.stopCapture()
            return
        }
        val foreground = GameTracking.foregroundPackage(this)
        val nowElapsed = SystemClock.elapsedRealtime()
        if (foreground != null && foreground in selected) {
            lastTrackedGameSeenAt = nowElapsed
            if (activeGamePackage != foreground) {
                finishActiveGameSession()
                FpsReader.stopCapture() // Never carry the previous game's FPS history into a new session.
                val packageName = foreground
                val appName = try { packageManager.getApplicationLabel(packageManager.getApplicationInfo(packageName, 0)).toString() } catch (_: Throwable) { packageName }
                activeGamePackage = packageName
                activeGameSessionId = gameStore.startSession(packageName, appName)
            }
        } else if (activeGamePackage != null && nowElapsed - lastTrackedGameSeenAt > 8_000L) {
            finishActiveGameSession()
            FpsReader.stopCapture()
        }

        val sessionId = activeGameSessionId ?: return
        // The FPS reader is deliberately invoked even if FPS/Frame Time checkboxes are off.
        FpsReader.requestUpdate(this) {
            if (activeGameSessionId == sessionId) saveGameSample(sessionId)
        }
    }

    private fun saveGameSample(sessionId: Long) {
        fun number(value: String): Double? = Regex("[0-9]+(?:[.,][0-9]+)?").find(value)?.value?.replace(',', '.')?.toDoubleOrNull()
        val battery = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val batteryTemp = battery?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE)?.takeIf { it in -200..1000 }?.div(10.0)
        val am = getSystemService(ACTIVITY_SERVICE) as ActivityManager
        val memory = ActivityManager.MemoryInfo()
        am.getMemoryInfo(memory)
        val usedMb = (memory.totalMem - memory.availMem) / 1_048_576L
        gameStore.addSample(
            sessionId,
            number(FpsReader.latest), number(FpsReader.latestAverage), number(FpsReader.latestOnePercentLow),
            number(FpsReader.latestFrameTime), CpuTemp.read()?.toDouble(), batteryTemp, usedMb,
            FpsReader.drainSessionFrameIntervals()
        )
    }

    private fun finishActiveGameSession() {
        val id = activeGameSessionId
        if (id != null) gameStore.finishSession(id)
        activeGameSessionId = null
        activeGamePackage = null
        lastTrackedGameSeenAt = 0L
    }

    private fun refreshOverlay() {
        if (!Prefs.overlay(this)) {
            bubble?.hide()
            // Do not stop capture here: game recording must continue when OSD is hidden.
            return
        }
        val fpsWanted = Prefs.fpsMonitoringEnabled(this)
        if (fpsWanted && GameTracking.selected(this).isEmpty()) FpsReader.requestUpdate(this) { renderCachedOverlay() }
        if (!refreshPending.compareAndSet(false, true)) return
        metricsWorker.execute {
            try {
                val now = SystemClock.elapsedRealtime()
                val enabled = Prefs.metrics(this).filter { it != "voltage" }
                val snapshot = synchronized(cachedMetrics) {
                    enabled.forEach { key ->
                        if (key in Prefs.FPS_METRICS) return@forEach
                        val interval = when (key) {
                            "cpu_temp" -> 3_000L
                            "battery_temp", "ram", "battery" -> 5_000L
                            "time" -> 30_000L
                            else -> 5_000L
                        }
                        if (!cachedMetrics.containsKey(key) || now - (lastMetricRead[key] ?: 0L) >= interval) {
                            metric(key)?.let { cachedMetrics[key] = it }
                            lastMetricRead[key] = now
                        }
                    }
                    LinkedHashMap<String, String>().also { result ->
                        enabled.forEach { key ->
                            when (key) {
                                "fps" -> result[key] = FpsReader.latest
                                "fps_avg" -> result[key] = FpsReader.latestAverage
                                "fps_1low" -> result[key] = FpsReader.latestOnePercentLow
                                "frametime" -> result[key] = FpsReader.latestFrameTime
                                "frametime_graph" -> result[key] = ""
                                else -> cachedMetrics[key]?.let { result[key] = it }
                            }
                        }
                    }
                }
                handler.post { showOverlay(snapshot) }
            } finally {
                refreshPending.set(false)
            }
        }
    }

    private fun renderCachedOverlay() {
        if (!Prefs.overlay(this)) return
        val values = LinkedHashMap<String, String>()
        synchronized(cachedMetrics) {
            Prefs.metrics(this).forEach { key ->
                when (key) {
                    "voltage" -> Unit
                    "fps" -> values[key] = FpsReader.latest
                    "fps_avg" -> values[key] = FpsReader.latestAverage
                    "fps_1low" -> values[key] = FpsReader.latestOnePercentLow
                    "frametime" -> values[key] = FpsReader.latestFrameTime
                    "frametime_graph" -> values[key] = ""
                    else -> cachedMetrics[key]?.let { values[key] = it }
                }
            }
        }
        showOverlay(values)
    }

    private fun showOverlay(values: Map<String, String>) {
        if (values.isEmpty()) { bubble?.hide(); return }
        if (bubble == null) bubble = FloatingBubble(this, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY)
        bubble?.show(values)
    }

    private fun batteryIntent() = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))

    private fun metric(key: String): String? = when (key) {
        "cpu_temp" -> CpuTemp.read()?.let { String.format(Locale.getDefault(), "%.1f °C", it) } ?: "н/д"
        "battery_temp" -> {
            val tenths = batteryIntent()?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE) ?: Int.MIN_VALUE
            if (tenths == Int.MIN_VALUE || tenths !in -200..1000) "н/д"
            else String.format(Locale.getDefault(), "%.1f °C", tenths / 10f)
        }
        "ram" -> {
            val am = getSystemService(ACTIVITY_SERVICE) as ActivityManager
            val mi = ActivityManager.MemoryInfo()
            am.getMemoryInfo(mi)
            "${(mi.totalMem - mi.availMem) / 1048576L} / ${mi.totalMem / 1048576L} MB"
        }
        "time" -> SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
        "fps" -> FpsReader.latest
        "battery" -> {
            val intent = batteryIntent()
            val level = intent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val scale = intent?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
            if (level < 0 || scale <= 0) "н/д" else {
                val percent = "${(level * 100 / scale).coerceIn(0, 100)}%"
                if (!Prefs.voltageDetailsEnabled(this)) percent else {
                    val millivolts = intent?.getIntExtra(BatteryManager.EXTRA_VOLTAGE, -1) ?: -1
                    val voltage = if (millivolts > 0) String.format(Locale.getDefault(), "%.2f В", millivolts / 1000f) else "вольтаж н/д"
                    val currentMicroAmps = (getSystemService(BATTERY_SERVICE) as BatteryManager)
                        .getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW)
                    val current = if (currentMicroAmps != Int.MIN_VALUE) {
                        val status = intent?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
                        val sign = when (status) {
                            BatteryManager.BATTERY_STATUS_CHARGING -> "+"
                            BatteryManager.BATTERY_STATUS_DISCHARGING -> "−"
                            else -> ""
                        }
                        "$sign${kotlin.math.abs(currentMicroAmps.toLong()) / 1000} мА"
                    } else "ток н/д"
                    "$percent · $voltage · $current"
                }
            }
        }
        else -> null
    }
    private fun createChannel() { if (Build.VERSION.SDK_INT >= 26) { val c=NotificationChannel(CHANNEL, "BatteryGuard", NotificationManager.IMPORTANCE_LOW).apply { description="Постоянная работа плавающего окна"; setShowBadge(false) }; getSystemService(NotificationManager::class.java).createNotificationChannel(c) } }
    private fun notification(): Notification {
        val stop=Intent(this, MonitorService::class.java).setAction(ACTION_STOP)
        val pi=PendingIntent.getService(this, 1, stop, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val open=PendingIntent.getActivity(this, 2, Intent(this, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_thermo)
            .setContentTitle("BatteryGuard работает")
            .setContentText("Плавающие системные показатели активны")
            .setContentIntent(open)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setOngoing(true).setOnlyAlertOnce(true)
            .addAction(R.drawable.ic_thermo, "Выключить", pi).build()
    }
    override fun onTaskRemoved(rootIntent: Intent?) {
        if (Prefs.isEnabled(this)) scheduleRestart()
        super.onTaskRemoved(rootIntent)
    }

    private fun scheduleRestart() {
        if (!Prefs.isEnabled(this)) return
        val alarm = getSystemService(ALARM_SERVICE) as AlarmManager
        val restart = Intent(this, ServiceRestartReceiver::class.java)
        val pending = PendingIntent.getBroadcast(
            this, 74, restart,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        alarm.setAndAllowWhileIdle(
            AlarmManager.ELAPSED_REALTIME_WAKEUP,
            SystemClock.elapsedRealtime() + 1800L,
            pending
        )
    }
    companion object { const val CHANNEL="batteryguard_monitor"; const val NOTIFICATION_ID=41; const val ACTION_STOP="batteryguard.STOP" }
}

