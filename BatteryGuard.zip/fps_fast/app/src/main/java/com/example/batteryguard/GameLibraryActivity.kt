package com.example.batteryguard

import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class GameLibraryActivity : AppCompatActivity() {
    private lateinit var list: LinearLayout
    private lateinit var usageStatus: TextView
    private lateinit var countTitle: TextView
    private val dateFormat = SimpleDateFormat("dd.MM.yyyy · HH:mm", Locale.getDefault())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(12), dp(16), dp(12)) }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val back = TextView(this).apply { text = "‹"; textSize = 34f; setPadding(dp(8), 0, dp(18), 0); setOnClickListener { finish() } }
        val title = TextView(this).apply { text = "Игры и статистика"; textSize = 22f; setTypeface(null, android.graphics.Typeface.BOLD) }
        header.addView(back); header.addView(title)
        root.addView(header)
        val description = TextView(this).apply {
            text = "Отметьте игры, за которыми нужно следить. BatteryGuard будет автоматически создавать отдельную игровую сессию при запуске выбранного приложения. Запись статистики не зависит от галочек OSD."
            textSize = 14f; setPadding(0, dp(10), 0, dp(12))
        }
        root.addView(description)
        val usageButton = com.google.android.material.button.MaterialButton(this).apply {
            text = "Разрешить доступ к статистике использования"
            setOnClickListener { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }
        }
        root.addView(usageButton)
        usageStatus = TextView(this).apply { id = View.generateViewId(); textSize = 12f; setPadding(0, dp(4), 0, dp(10)) }
        root.addView(usageStatus)
        countTitle = TextView(this).apply { text = "Выберите игры"; textSize = 17f; setTypeface(null, android.graphics.Typeface.BOLD); setPadding(0, dp(8), 0, dp(8)) }
        root.addView(countTitle)
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(this).apply { addView(list) }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        renderGames()
    }

    override fun onResume() { super.onResume(); if (::list.isInitialized) renderGames() }

    private data class AppEntry(val packageName: String, val label: String, val icon: android.graphics.drawable.Drawable)

    private fun renderGames() {
        list.removeAllViews()
        val access = GameTracking.hasUsageAccess(this)
        usageStatus.text = if (access) "Доступ разрешён — автоматическое определение игр активно" else "Нужно включить специальный доступ Usage Access. Без него Android не позволяет надёжно определить активную игру."
        val selected = GameTracking.selected(this).toMutableSet()
        val apps = packageManager.getInstalledApplications(0).mapNotNull { info ->
            val packageName = info.packageName
            if (packageName == this.packageName) return@mapNotNull null
            if (packageManager.getLaunchIntentForPackage(packageName) == null) return@mapNotNull null
            try { AppEntry(packageName, packageManager.getApplicationLabel(info).toString(), packageManager.getApplicationIcon(info)) } catch (_: Throwable) { null }
        }.filter { it.packageName != this.packageName }.sortedBy { it.label.lowercase(Locale.getDefault()) }
        for (app in apps) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(4), dp(6), dp(4), dp(6)) }
            val icon = android.widget.ImageView(this).apply { setImageDrawable(app.icon); layoutParams = LinearLayout.LayoutParams(dp(42), dp(42)).apply { marginEnd = dp(10) } }
            val check = CheckBox(this).apply {
                text = app.label
                isChecked = app.packageName in selected
                textSize = 15f
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
                setOnCheckedChangeListener { _, checked ->
                    if (checked) selected.add(app.packageName) else selected.remove(app.packageName)
                    GameTracking.setSelected(this@GameLibraryActivity, selected)
                    countSelected(selected.size)
                }
            }
            val history = TextView(this).apply { text = "▤"; textSize = 24f; gravity = Gravity.CENTER; layoutParams = LinearLayout.LayoutParams(dp(44), dp(48)); contentDescription = "Статистика ${app.label}"; setOnClickListener { showHistory(app.packageName, app.label) } }
            row.addView(icon); row.addView(check); row.addView(history)
            list.addView(row)
            list.addView(View(this).apply { setBackgroundColor(0x22333333) }, LinearLayout.LayoutParams(-1, dp(1)))
        }
        countSelected(selected.size)
    }

    private fun countSelected(count: Int) {
        countTitle.text = "Выбрано игр: $count"
    }

    private fun showHistory(packageName: String, appName: String) {
        val sessions = GameStatsStore(this).sessions(packageName)
        if (sessions.isEmpty()) {
            AlertDialog.Builder(this).setTitle(appName).setMessage("Для этой игры пока нет сохранённых сессий. Отметьте игру и запустите её при включённом BatteryGuard.").setPositiveButton("Понятно", null).show()
            return
        }
        val lines = sessions.take(20).joinToString("\n\n") { s ->
            val duration = ((if (s.endedAt > 0) s.endedAt else System.currentTimeMillis()) - s.startedAt).coerceAtLeast(0) / 60_000L
            val avg = s.avgFps?.let { "%.1f FPS".format(Locale.US, it) } ?: "н/д"
            val low = s.lowFps?.let { "%.1f FPS".format(Locale.US, it) } ?: "н/д"
            val ft = s.avgFrameTime?.let { "%.1f ms".format(Locale.US, it) } ?: "н/д"
            val cpu = s.avgCpuTemp?.let { "%.1f °C".format(Locale.US, it) } ?: "н/д"
            val battery = s.avgBatteryTemp?.let { "%.1f °C".format(Locale.US, it) } ?: "н/д"
            val ram = s.avgRamMb?.let { "%.0f MB".format(Locale.US, it) } ?: "н/д"
            "${dateFormat.format(Date(s.startedAt))}\nДлительность: ${duration / 60} ч ${duration % 60} мин\nСредний FPS: $avg · 1% Low: $low\nСредний Frame Time: $ft\nCPU: $cpu · Батарея: $battery\nИспользование ОЗУ: $ram\nЗамеров: ${s.sampleCount}"
        }
        AlertDialog.Builder(this).setTitle("$appName · сессии").setMessage(lines).setPositiveButton("Закрыть", null).show()
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
}
