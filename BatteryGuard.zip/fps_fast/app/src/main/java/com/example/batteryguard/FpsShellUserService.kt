package com.example.batteryguard

/** Shizuku launches this service as Android shell UID (2000), not root. */
class FpsShellUserService : IFpsShellService.Stub() {
    override fun exec(command: String): String {
        return try {
            val process = ProcessBuilder("sh", "-c", command)
                .redirectErrorStream(true)
                .start()
            val reader = java.util.concurrent.CompletableFuture.supplyAsync {
                process.inputStream.bufferedReader().use { it.readText() }
            }
            val finished = process.waitFor(12, java.util.concurrent.TimeUnit.SECONDS)
            if (!finished) {
                process.destroyForcibly()
                "!!EXIT:TIMEOUT"
            } else {
                val output = try { reader.get(2, java.util.concurrent.TimeUnit.SECONDS) } catch (_: Throwable) { "" }
                if (process.exitValue() == 0) output else "!!EXIT:${process.exitValue()}\n$output"
            }
        } catch (t: Throwable) {
            "!!EXIT:${t.javaClass.simpleName}:${t.message ?: "error"}"
        }
    }
}
