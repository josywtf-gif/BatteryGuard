package com.example.batteryguard

import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context

object GameTracking {
    private const val KEY = "tracked_game_packages"
    @Volatile private var lastEventTimestamp = 0L
    @Volatile private var cachedForegroundPackage: String? = null
    @Volatile private var cachedIsForeground = false

    fun selected(context: Context): Set<String> = Prefs.sp(context).getStringSet(KEY, emptySet())?.toSet() ?: emptySet()
    fun setSelected(context: Context, packages: Set<String>) { Prefs.sp(context).edit().putStringSet(KEY, packages).apply() }

    fun hasUsageAccess(context: Context): Boolean = try {
        val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as android.app.AppOpsManager
        val mode = if (android.os.Build.VERSION.SDK_INT >= 29) {
            appOps.unsafeCheckOpNoThrow(android.app.AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), context.packageName)
        } else {
            appOps.checkOpNoThrow(android.app.AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), context.packageName)
        }
        mode == android.app.AppOpsManager.MODE_ALLOWED
    } catch (_: Throwable) { false }

    /** Maintains the latest resumed app from UsageStats events, querying incrementally after startup. */
    @Synchronized fun foregroundPackage(context: Context): String? {
        if (!hasUsageAccess(context)) return null
        val manager = context.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val now = System.currentTimeMillis()
        // On first call recover current foreground state; later calls only inspect new/recent events.
        val from = if (lastEventTimestamp == 0L) now - 6L * 60L * 60L * 1000L else maxOf(now - 20_000L, lastEventTimestamp - 1L)
        val events = manager.queryEvents(from, now)
        val event = UsageEvents.Event()
        while (events.hasNextEvent()) {
            events.getNextEvent(event)
            if (event.timeStamp < lastEventTimestamp && lastEventTimestamp != 0L) continue
            val resumed = event.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND ||
                (android.os.Build.VERSION.SDK_INT >= 29 && event.eventType == UsageEvents.Event.ACTIVITY_RESUMED)
            val paused = event.eventType == UsageEvents.Event.MOVE_TO_BACKGROUND ||
                (android.os.Build.VERSION.SDK_INT >= 29 && event.eventType == UsageEvents.Event.ACTIVITY_PAUSED)
            val screenOff = android.os.Build.VERSION.SDK_INT >= 28 && event.eventType == UsageEvents.Event.SCREEN_NON_INTERACTIVE
            if (resumed) {
                cachedForegroundPackage = event.packageName
                cachedIsForeground = true
            } else if ((paused && event.packageName == cachedForegroundPackage) || screenOff) {
                cachedIsForeground = false
            }
            if (event.timeStamp > lastEventTimestamp) lastEventTimestamp = event.timeStamp
        }
        return cachedForegroundPackage?.takeIf { cachedIsForeground && it != context.packageName }
    }
}
