package com.example.batteryguard

import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.content.ServiceConnection
import rikka.shizuku.Shizuku
import java.util.ArrayDeque
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.math.ceil

/** Reads real presented-frame timestamps through Shizuku (ADB shell UID); never uses display Hz. */
object FpsReader {
    private const val STALE_AFTER_MS = 8_000L
    private const val HISTORY_MS = 60_000L
    @Volatile private var lastValidAtMs = 0L
    @Volatile private var currentFps = "н/д"
    @Volatile private var averageFps = "н/д"
    @Volatile private var onePercentLow = "н/д"
    @Volatile private var frameTime = "н/д"
    @Volatile private var lastFrameTimeNs = 0L
    @Volatile private var frameGraph = emptyList<Float>()
    private data class Interval(val atNs: Long, val ms: Double)
    private val intervals = ArrayDeque<Interval>()
    private val historyLock = Any()

    private fun fresh() = lastValidAtMs > 0L && SystemClock.elapsedRealtime() - lastValidAtMs <= STALE_AFTER_MS
    val latest: String get() = if (fresh()) currentFps else "н/д"
    val latestAverage: String get() = if (fresh()) averageFps else "н/д"
    val latestOnePercentLow: String get() = if (fresh()) onePercentLow else "н/д"
    val latestFrameTime: String get() = if (fresh()) frameTime else "н/д"
    val frameTimeGraphSamples: List<Float> get() = if (fresh()) frameGraph else emptyList()

    private fun clearLastValue() {
        synchronized(historyLock) {
            intervals.clear(); frameGraph = emptyList(); lastFrameTimeNs = 0L
        }
        currentFps = "н/д"; averageFps = "н/д"; onePercentLow = "н/д"; frameTime = "н/д"; lastValidAtMs = 0L
    }

    private fun publishFrameTimestamps(input: List<Long>): Int? {
        val nowNs = System.nanoTime()
        synchronized(historyLock) {
            val newestInput = input.maxOrNull() ?: return null
            // SurfaceFlinger may restart and reset its timestamp stream; start a fresh window.
            if (lastFrameTimeNs > 0L && newestInput < lastFrameTimeNs - 5_000_000_000L) {
                intervals.clear()
                frameGraph = emptyList()
                lastFrameTimeNs = 0L
            }
            input.filter { it > lastFrameTimeNs }.sorted().forEach { ts ->
                if (lastFrameTimeNs > 0L) {
                    val deltaMs = (ts - lastFrameTimeNs) / 1_000_000.0
                    if (deltaMs in 1.0..1000.0) intervals.addLast(Interval(ts, deltaMs))
                }
                lastFrameTimeNs = ts
            }
            while (intervals.isNotEmpty() && nowNs - intervals.first().atNs > HISTORY_MS * 1_000_000L) intervals.removeFirst()
            if (intervals.isEmpty()) return null

            val recent = intervals.filter { nowNs - it.atNs <= 2_500_000_000L }
            val avgRecentMs = recent.map { it.ms }.average().takeIf { !it.isNaN() && it > 0.0 }
            val fps = avgRecentMs?.let { (1000.0 / it).toInt().coerceIn(1, 1000) } ?: return null
            val allAvg = intervals.map { it.ms }.average()
            currentFps = "$fps FPS"
            frameTime = String.format(Locale.US, "%.1f ms", avgRecentMs)
            averageFps = if (allAvg > 0.0) "${(1000.0 / allAvg).toInt()} FPS" else "н/д"
            onePercentLow = if (intervals.size >= 1000) {
                val slowestCount = ceil(intervals.size * 0.01).toInt().coerceAtLeast(1)
                val slowest = intervals.map { it.ms }.sortedDescending().take(slowestCount).average()
                if (slowest > 0.0) "${(1000.0 / slowest).toInt()} FPS" else "н/д"
            } else "н/д"

            // Keep individual frame durations for a useful frametime graph with visible spikes.
            frameGraph = intervals.toList().takeLast(180).map { it.ms.toFloat() }
            lastValidAtMs = SystemClock.elapsedRealtime()
            return fps
        }
    }

    @Volatile var diagnostic: String = "Ожидание подключения Shizuku"
        private set
    @Volatile private var running = false
    @Volatile private var shell: IFpsShellService? = null
    @Volatile private var bindRequested = false
    @Volatile private var timestatsEnabled = false
    private var cachedLayerPackage: String? = null
    private var currentPackage: String? = null
    private var cachedLayers: List<String> = emptyList()
    private var cachedLayersAt = 0L
    private val worker = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())
    private lateinit var userServiceArgs: Shizuku.UserServiceArgs

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
            shell = IFpsShellService.Stub.asInterface(service); bindRequested = false
            diagnostic = if (shell != null) "ADB Shell подключён" else "Не удалось подключить ADB Shell"
        }
        override fun onServiceDisconnected(name: ComponentName?) {
            shell = null; bindRequested = false; timestatsEnabled = false
            diagnostic = "Соединение Shizuku потеряно"
        }
    }

    fun hasShizukuPermission(): Boolean = try { Shizuku.pingBinder() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED } catch (_: Throwable) { false }
    fun shizukuRunning(): Boolean = try { Shizuku.pingBinder() } catch (_: Throwable) { false }

    @Synchronized fun connect(context: Context): Boolean {
        if (!hasShizukuPermission()) { diagnostic = if (!shizukuRunning()) "Shizuku не запущен" else "Нет разрешения Shizuku"; return false }
        if (shell != null) return true
        if (bindRequested) return false
        return try {
            userServiceArgs = Shizuku.UserServiceArgs(ComponentName(context.applicationContext, FpsShellUserService::class.java))
                .daemon(true).processNameSuffix("fps_shell").tag("BatteryGuardFpsShell").version(3)
            bindRequested = true; diagnostic = "Подключение к системной службе…"
            Shizuku.bindUserService(userServiceArgs, connection); false
        } catch (t: Throwable) { bindRequested = false; diagnostic = "Ошибка запуска ADB Shell: ${t.javaClass.simpleName}"; false }
    }

    fun requestUpdate(context: Context, onResult: (() -> Unit)? = null) {
        if (running) return
        if (!hasShizukuPermission()) {
            clearLastValue(); diagnostic = if (!shizukuRunning()) "Shizuku не запущен" else "Нет разрешения Shizuku"
            onResult?.let { main.post(it) }; return
        }
        if (shell == null) { connect(context); onResult?.let { main.post(it) }; return }
        running = true
        worker.execute {
            try {
                val fps = readForegroundFps(context)
                if (fps == null) diagnostic = "Ожидание кадров активного приложения"
                else diagnostic = "Реальные кадры SurfaceFlinger"
            } catch (t: Throwable) { diagnostic = "Ошибка измерения: ${t.javaClass.simpleName}" }
            running = false
            onResult?.let { main.post(it) }
        }
    }

    private fun commandResult(command: String): String? {
        val result = try { shell?.exec(command) } catch (t: Throwable) { diagnostic = "ADB-команда недоступна: ${t.javaClass.simpleName}"; null }
        if (result == null) return null
        if (result.startsWith("!!EXIT:")) { diagnostic = "Системная команда завершилась с ошибкой: ${result.substringBefore('\n')}"; return null }
        return result
    }
    private fun command(command: String): String? = commandResult(command)?.takeIf { it.isNotBlank() }

    fun stopCapture() {
        val wasEnabled = timestatsEnabled
        timestatsEnabled = false
        cachedLayerPackage = null
        cachedLayers = emptyList()
        currentPackage = null
        clearLastValue()
        if (wasEnabled) worker.execute { commandResult("dumpsys SurfaceFlinger --timestats -disable") }
    }

    /** Any foreground app is eligible; user controls monitoring by enabling/disabling FPS metrics. */
    private fun readForegroundFps(context: Context): Int? {
        val activityDump = command("dumpsys activity activities").orEmpty()
        val resumedPattern = Regex("(?:topResumedActivity|mResumedActivity)\\s*[:=]\\s*ActivityRecord\\{[^}]*?\\bu\\d+\\s+([A-Za-z0-9_.]+)/")
        val resumed = resumedPattern.findAll(activityDump).lastOrNull()?.groupValues?.getOrNull(1)
        val fallback = Regex("ActivityRecord\\{[^}]*?\\bu\\d+\\s+([A-Za-z0-9_.]+)/").findAll(activityDump).lastOrNull()?.groupValues?.getOrNull(1)
        val packageName = resumed ?: fallback
        if (packageName.isNullOrBlank() || packageName == context.packageName) return null
        if (currentPackage != packageName) {
            clearLastValue()
            currentPackage = packageName
        }

        val now = SystemClock.elapsedRealtime()
        if (cachedLayerPackage != packageName || now - cachedLayersAt > 10_000L || cachedLayers.isEmpty()) {
            val dump = command("dumpsys SurfaceFlinger --list")
            cachedLayers = dump.orEmpty().lineSequence().map { it.trim() }
                .filter { it.contains(packageName, true) }
                .sortedByDescending { layerRank(it) }.take(3).toList()
            cachedLayerPackage = packageName; cachedLayersAt = now
        }
        var bestTimestamps: List<Long> = emptyList()
        if (cachedLayers.isNotEmpty()) {
            // One shell session for all candidate layers avoids spawning a shell per surface.
            val batch = cachedLayers.joinToString("\n") { layer ->
                "printf '\\n__BG_LAYER__%s\\n' ${shellQuote(layer)}; dumpsys SurfaceFlinger --latency ${shellQuote(layer)}"
            }
            val dump = command(batch).orEmpty()
            val markers = Regex("(?m)^__BG_LAYER__(.*)$").findAll(dump).toList()
            var bestRank = -1
            for (i in markers.indices) {
                val layer = markers[i].groupValues[1].trim()
                val end = if (i + 1 < markers.size) markers[i + 1].range.first else dump.length
                val section = dump.substring(markers[i].range.last + 1, end)
                val timestamps = parseLatencyTimestamps(section)
                val rank = layerRank(layer)
                if (timestamps.size >= 3 && (rank > bestRank || (rank == bestRank && timestamps.size > bestTimestamps.size))) {
                    bestRank = rank
                    bestTimestamps = timestamps
                }
            }
        }
        if (bestTimestamps.size >= 2) {
            publishFrameTimestamps(bestTimestamps)?.let { return it }
        }
        // OEM fallback: timestats provides current/average FPS but not per-frame timing data.
        val fallbackFps = readTimestatsFps(packageName)
        if (fallbackFps != null) {
            currentFps = "$fallbackFps FPS"; averageFps = "н/д"; onePercentLow = "н/д"; frameTime = "н/д"; frameGraph = emptyList()
            lastValidAtMs = SystemClock.elapsedRealtime()
            return fallbackFps
        }
        return null
    }

    private fun layerRank(layer: String) = when {
        layer.contains("SurfaceView", true) -> 4
        layer.contains("BLAST", true) -> 3
        layer.contains("BufferQueue", true) -> 2
        else -> 1
    }

    private fun readTimestatsFps(packageName: String): Int? {
        if (!timestatsEnabled) {
            if (commandResult("dumpsys SurfaceFlinger --timestats -clear -enable") == null) return null
            timestatsEnabled = true
        }
        val dump = command("dumpsys SurfaceFlinger --timestats -dump") ?: return null
        val sections = Regex("(?m)^\\s*layerName\\s*=\\s*(.+)$").findAll(dump).toList()
        val candidates = mutableListOf<Pair<Int, Double>>()
        for (i in sections.indices) {
            val name = sections[i].groupValues[1].trim()
            if (!name.contains(packageName, true)) continue
            val end = if (i + 1 < sections.size) sections[i + 1].range.first else dump.length
            val section = dump.substring(sections[i].range.last + 1, end)
            val fps = Regex("(?m)^\\s*averageFPS\\s*=\\s*([0-9]+(?:\\.[0-9]+)?)").find(section)?.groupValues?.getOrNull(1)?.toDoubleOrNull() ?: continue
            if (fps in 1.0..360.0) candidates += layerRank(name) to fps
        }
        if (candidates.isEmpty()) return null
        return candidates.maxWithOrNull(compareBy<Pair<Int, Double>> { it.first }.thenBy { it.second })?.second?.toInt()
    }

    private fun parseLatencyTimestamps(dump: String): List<Long> = dump.lineSequence().drop(1).mapNotNull { line ->
        val cols = line.trim().split(Regex("\\s+"))
        // SurfaceFlinger latency columns: desired-present, actual-present, frame-ready.
        cols.getOrNull(1)?.toLongOrNull()?.takeIf { it > 0L }
    }.distinct().sorted().toList()

    private fun shellQuote(value: String) = "'" + value.replace("'", "'\\''") + "'"
}
