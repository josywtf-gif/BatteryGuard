package com.example.batteryguard

import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.content.ServiceConnection
import rikka.shizuku.Shizuku
import java.util.concurrent.Executors

/**
 * Best-effort real presented-frame counter. Runs dumpsys as Android shell UID through Shizuku;
 * never uses root and never substitutes display refresh rate for game FPS.
 */
object FpsReader {
    // Keep the last measured value through brief SurfaceFlinger/Shizuku sampling gaps.
    // Only report unavailable after several consecutive seconds without a valid sample.
    private const val STALE_AFTER_MS = 8_000L
    @Volatile private var lastValidValue: String = "н/д"
    @Volatile private var lastValidAtMs: Long = 0L
    val latest: String
        get() = if (lastValidAtMs > 0L && SystemClock.elapsedRealtime() - lastValidAtMs <= STALE_AFTER_MS) {
            lastValidValue
        } else {
            "н/д"
        }

    private fun clearLastValue() {
        lastValidValue = "н/д"
        lastValidAtMs = 0L
    }

    private fun publishResult(value: String) {
        if (value != "н/д") {
            lastValidValue = value
            lastValidAtMs = SystemClock.elapsedRealtime()
        }
    }
    @Volatile var diagnostic: String = "Ожидание подключения Shizuku"
        private set
    @Volatile private var running = false
    @Volatile private var shell: IFpsShellService? = null
    @Volatile private var bindRequested = false
    @Volatile private var timestatsEnabled = false
    private val worker = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())
    private lateinit var userServiceArgs: Shizuku.UserServiceArgs

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
            shell = IFpsShellService.Stub.asInterface(service)
            bindRequested = false
            diagnostic = if (shell != null) "ADB Shell подключён. Ожидание кадров игры…" else "Не удалось подключить ADB Shell"
        }
        override fun onServiceDisconnected(name: ComponentName?) {
            shell = null
            bindRequested = false
            diagnostic = "Соединение Shizuku потеряно"
        }
    }

    fun hasShizukuPermission(): Boolean = try {
        Shizuku.pingBinder() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (_: Throwable) { false }

    fun shizukuRunning(): Boolean = try { Shizuku.pingBinder() } catch (_: Throwable) { false }

    @Synchronized
    fun connect(context: Context): Boolean {
        if (!hasShizukuPermission()) {
            diagnostic = if (!shizukuRunning()) "Shizuku не запущен" else "Нет разрешения Shizuku"
            return false
        }
        if (shell != null) return true
        if (bindRequested) return false
        return try {
            userServiceArgs = Shizuku.UserServiceArgs(
                ComponentName(context.applicationContext, FpsShellUserService::class.java)
            ).daemon(true).processNameSuffix("fps_shell").tag("BatteryGuardFpsShell").version(2)
            bindRequested = true
            diagnostic = "Подключение к системной службе…"
            Shizuku.bindUserService(userServiceArgs, connection)
            false
        } catch (t: Throwable) {
            bindRequested = false
            diagnostic = "Ошибка запуска ADB Shell: ${t.javaClass.simpleName}"
            false
        }
    }

    fun requestUpdate(context: Context, onResult: ((String) -> Unit)? = null) {
        if (running) return
        if (!hasShizukuPermission()) {
            clearLastValue()
            diagnostic = if (!shizukuRunning()) "Запустите Shizuku через беспроводную отладку" else "Разрешите BatteryGuard доступ в Shizuku"
            onResult?.let { main.post { it(latest) } }
            return
        }
        if (shell == null) {
            connect(context)
            // Binding can briefly reconnect; don't flash н/д while the previous sample is fresh.
            onResult?.let { main.post { it(latest) } }
            return
        }
        running = true
        worker.execute {
            val result = try {
                val fps = readGameFps()
                if (fps != null) {
                    diagnostic = "Получены кадры активного приложения"
                    "$fps FPS"
                } else {
                    "н/д"
                }
            } catch (t: Throwable) {
                diagnostic = "Ошибка измерения: ${t.javaClass.simpleName}"
                "н/д"
            }
            publishResult(result)
            running = false
            val displayed = latest
            onResult?.let { main.post { it(displayed) } }
        }
    }

    private fun commandResult(command: String): String? {
        val result = try { shell?.exec(command) } catch (t: Throwable) {
            diagnostic = "ADB-команда недоступна: ${t.javaClass.simpleName}"
            null
        }
        if (result == null) return null
        if (result.startsWith("!!EXIT:")) {
            diagnostic = "Системная команда завершилась с ошибкой: ${result.substringBefore('\n')}"
            return null
        }
        return result
    }

    private fun command(command: String): String? = commandResult(command)?.takeIf { it.isNotBlank() }

    fun stopCapture() {
        if (!timestatsEnabled) return
        timestatsEnabled = false
        worker.execute {
            commandResult("dumpsys SurfaceFlinger --timestats -disable")
        }
    }

    private fun readGameFps(): Int? {
        val activityDump = command("dumpsys activity activities").orEmpty()
        val resumedPattern = Regex("(?:topResumedActivity|mResumedActivity)\\s*[:=]\\s*ActivityRecord\\{[^}]*?\\bu\\d+\\s+([A-Za-z0-9_.]+)/")
        val resumed = resumedPattern.findAll(activityDump).lastOrNull()?.groupValues?.getOrNull(1)
        val activityFallback = Regex("ActivityRecord\\{[^}]*?\\bu\\d+\\s+([A-Za-z0-9_.]+)/")
            .findAll(activityDump).lastOrNull()?.groupValues?.getOrNull(1)
        val windowDump = if (resumed == null && activityFallback == null) command("dumpsys window windows").orEmpty() else ""
        val windowPackage = Regex("(?:mCurrentFocus|mFocusedApp).*?([A-Za-z0-9_.]+)/")
            .findAll(windowDump).lastOrNull()?.groupValues?.getOrNull(1)
        val packageName = resumed ?: activityFallback ?: windowPackage
        if (packageName.isNullOrBlank() || packageName == "com.example.batteryguard") {
            diagnostic = "Не удалось определить активное приложение. Откройте игру на переднем плане"
            return null
        }

        // Primary path recommended by Android Developers: SurfaceFlinger timestats.
        // Unlike the legacy --latency ring buffer, timestats exposes per-layer averageFPS
        // and covers OpenGL, Vulkan and Android UI surfaces.
        readTimestatsFps(packageName)?.let { return it }

        // Compatibility fallback for OEM builds where timestats is unavailable/blocked.
        val layerDump = command("dumpsys SurfaceFlinger --list")
        if (layerDump.isNullOrBlank()) {
            diagnostic = "Список слоёв SurfaceFlinger недоступен; проверяем gfxinfo"
            return readGfxInfoFallback(packageName)
        }
        val packageLayers = layerDump.lineSequence().map { it.trim() }
            .filter { it.contains(packageName, ignoreCase = true) }
            .toList()
        if (packageLayers.isEmpty()) {
            diagnostic = "SurfaceFlinger не показывает слои приложения $packageName"
            return readGfxInfoFallback(packageName)
        }
        // Prefer game surfaces, but also test other app-owned layers: OEMs name them differently.
        val ranked = packageLayers.sortedByDescending { layer ->
            when {
                layer.contains("SurfaceView", true) -> 4
                layer.contains("BLAST", true) -> 3
                layer.contains("BufferQueue", true) -> 2
                else -> 1
            }
        }.take(12)

        var best: Int? = null
        for (layer in ranked) {
            val dump = command("dumpsys SurfaceFlinger --latency ${shellQuote(layer)}") ?: continue
            val timestamps = parseLatencyTimestamps(dump)
            val fps = calculateFps(timestamps)
            if (fps != null && (best == null || fps > best!!)) best = fps
        }
        if (best != null) return best

        diagnostic = "Слои игры найдены, но SurfaceFlinger не отдаёт временные метки кадров"
        return readGfxInfoFallback(packageName)
    }


    /**
     * Reads actual per-layer frame statistics from SurfaceFlinger.
     * A short capture window is used so the overlay reflects current gameplay, not a
     * lifetime average accumulated since boot. FPS polling runs about once per second. The display refresh rate is never used.
     */
    private fun readTimestatsFps(packageName: String): Int? {
        // Empty stdout is a valid result for this control command; only a shell error means failure.
        val started = commandResult("dumpsys SurfaceFlinger --timestats -clear -enable")
        if (started == null) {
            diagnostic = "SurfaceFlinger timestats недоступен; пробуем совместимый режим"
            return null
        }
        timestatsEnabled = true

        // Collect a short rolling sample. The service polls about once per second,
        // keeping FPS responsive without repeatedly blocking the UI thread.
        try { Thread.sleep(700L) } catch (_: InterruptedException) {
            Thread.currentThread().interrupt()
            diagnostic = "Измерение FPS прервано"
            return null
        }

        val dump = command("dumpsys SurfaceFlinger --timestats -dump")
        if (dump.isNullOrBlank()) {
            diagnostic = "SurfaceFlinger не вернул timestats; пробуем совместимый режим"
            return null
        }

        val sections = Regex("(?m)^\\s*layerName\\s*=\\s*(.+)$").findAll(dump).toList()
        val candidates = mutableListOf<Pair<Int, Int>>()
        for (i in sections.indices) {
            val layerName = sections[i].groupValues[1].trim()
            if (!layerName.contains(packageName, ignoreCase = true)) continue
            val end = if (i + 1 < sections.size) sections[i + 1].range.first else dump.length
            val section = dump.substring(sections[i].range.last + 1, end)
            val rawFps = Regex("(?m)^\\s*averageFPS\\s*=\\s*([0-9]+(?:\\.[0-9]+)?)")
                .find(section)?.groupValues?.getOrNull(1)?.toDoubleOrNull() ?: continue
            val fps = rawFps.toInt()
            if (fps !in 1..360) continue
            val rank = when {
                layerName.contains("SurfaceView", true) -> 4
                layerName.contains("BLAST", true) -> 3
                layerName.contains("BufferQueue", true) -> 2
                else -> 1
            }
            candidates += rank to fps
        }
        if (candidates.isNotEmpty()) {
            // Prefer the game's primary rendering surface, then the highest valid layer rate.
            val bestRank = candidates.maxOf { it.first }
            val fps = candidates.filter { it.first == bestRank }.maxOf { it.second }
            diagnostic = "FPS получен через SurfaceFlinger timestats ($packageName)"
            return fps
        }

        diagnostic = if (sections.isEmpty()) {
            "Эта прошивка не вернула данные SurfaceFlinger timestats"
        } else {
            "В timestats нет активного слоя приложения $packageName"
        }
        return null
    }

    private fun parseLatencyTimestamps(dump: String): List<Long> {
        return dump.lineSequence().drop(1).mapNotNull { line ->
            val cols = line.trim().split(Regex("\\s+")).mapNotNull { it.toLongOrNull() }
            if (cols.size < 2) null else cols[1].takeIf { it > 0L }
        }.distinct().sorted().toList()
    }

    private fun calculateFps(all: List<Long>): Int? {
        if (all.size < 3) return null
        val latestNs = all.last()
        // Use the most recent actual-present timestamps. Comparing shell timestamps with the
        // app process clock caused false negatives on some vendor builds.
        val recent = all.filter { latestNs - it <= 2_500_000_000L }.takeLast(90)
        if (recent.size < 3) return null
        val span = recent.last() - recent.first()
        if (span <= 0L) return null
        val fps = ((recent.size - 1) * 1_000_000_000.0 / span).toInt()
        return fps.takeIf { it in 1..360 }
    }

    /** Fallback works for HWUI-rendered apps; many native Vulkan games do not expose gfxinfo frames. */
    private fun readGfxInfoFallback(packageName: String): Int? {
        val dump = command("dumpsys gfxinfo $packageName framestats") ?: return null
        val header = dump.lineSequence().firstOrNull { it.contains("FrameCompleted", true) } ?: run {
            diagnostic += ". gfxinfo не содержит FrameCompleted"
            return null
        }
        val columns = header.split(',').map { it.trim() }
        val index = columns.indexOfFirst { it.equals("FrameCompleted", true) }
        if (index < 0) return null
        val times = dump.lineSequence().filter { it.startsWith("0,") || it.startsWith("1,") }
            .mapNotNull { line -> line.split(',').getOrNull(index)?.trim()?.toLongOrNull()?.takeIf { it > 0L } }
            .distinct().sorted().toList().takeLast(90)
        val fps = calculateFps(times)
        if (fps == null) diagnostic += ". gfxinfo не предоставил достаточно кадров"
        else diagnostic = "FPS получен через gfxinfo (HWUI)"
        return fps
    }

    private fun shellQuote(value: String) = "'" + value.replace("'", "'\\''") + "'"
}
