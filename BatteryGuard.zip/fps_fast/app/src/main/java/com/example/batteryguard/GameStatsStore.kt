package com.example.batteryguard

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

/** Persistent per-game session history. OSD settings never clear or reset these records. */
class GameStatsStore(context: Context) : SQLiteOpenHelper(context, "game_stats.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE sessions (id INTEGER PRIMARY KEY AUTOINCREMENT, package_name TEXT NOT NULL, app_name TEXT NOT NULL, started_at INTEGER NOT NULL, ended_at INTEGER NOT NULL DEFAULT 0)")
        db.execSQL("CREATE INDEX sessions_package_started ON sessions(package_name, started_at DESC)")
        db.execSQL("CREATE TABLE samples (id INTEGER PRIMARY KEY AUTOINCREMENT, session_id INTEGER NOT NULL, captured_at INTEGER NOT NULL, fps REAL, avg_fps REAL, low_fps REAL, frame_time REAL, cpu_temp REAL, battery_temp REAL, ram_used_mb INTEGER, FOREIGN KEY(session_id) REFERENCES sessions(id))")
        db.execSQL("CREATE INDEX samples_session_time ON samples(session_id, captured_at)")
        db.execSQL("CREATE TABLE frame_intervals (id INTEGER PRIMARY KEY AUTOINCREMENT, session_id INTEGER NOT NULL, frame_time_ms REAL NOT NULL)")
        db.execSQL("CREATE INDEX frame_intervals_session ON frame_intervals(session_id)")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}

    @Synchronized fun startSession(packageName: String, appName: String, at: Long = System.currentTimeMillis()): Long {
        val values = ContentValues().apply { put("package_name", packageName); put("app_name", appName); put("started_at", at); put("ended_at", 0L) }
        return writableDatabase.insert("sessions", null, values)
    }
    @Synchronized fun finishSession(id: Long, at: Long = System.currentTimeMillis()) {
        writableDatabase.update("sessions", ContentValues().apply { put("ended_at", at) }, "id=?", arrayOf(id.toString()))
    }
    @Synchronized fun addSample(id: Long, fps: Double?, avg: Double?, low: Double?, frameTime: Double?, cpu: Double?, battery: Double?, ram: Long?, frameIntervals: List<Float>) {
        val values = ContentValues().apply {
            put("session_id", id); put("captured_at", System.currentTimeMillis())
            putNullable("fps", fps); putNullable("avg_fps", avg); putNullable("low_fps", low)
            putNullable("frame_time", frameTime); putNullable("cpu_temp", cpu); putNullable("battery_temp", battery)
            if (ram != null) put("ram_used_mb", ram)
        }
        val db = writableDatabase
        db.insert("samples", null, values)
        if (frameIntervals.isNotEmpty()) {
            db.beginTransaction()
            try {
                frameIntervals.forEach { interval ->
                    if (interval in 1f..1000f) db.insert("frame_intervals", null, ContentValues().apply { put("session_id", id); put("frame_time_ms", interval.toDouble()) })
                }
                db.setTransactionSuccessful()
            } finally { db.endTransaction() }
        }
    }
    private fun ContentValues.putNullable(key: String, value: Double?) { if (value == null || value.isNaN() || value.isInfinite()) putNull(key) else put(key, value) }

    data class SessionSummary(val id: Long, val packageName: String, val appName: String, val startedAt: Long, val endedAt: Long, val avgFps: Double?, val lowFps: Double?, val avgFrameTime: Double?, val avgCpuTemp: Double?, val avgBatteryTemp: Double?, val avgRamMb: Double?, val sampleCount: Int)
    @Synchronized fun sessions(packageName: String): List<SessionSummary> {
        val result = mutableListOf<SessionSummary>()
        readableDatabase.rawQuery("SELECT s.id,s.package_name,s.app_name,s.started_at,s.ended_at,AVG(p.fps),AVG(p.frame_time),AVG(p.cpu_temp),AVG(p.battery_temp),AVG(p.ram_used_mb),COUNT(p.id) FROM sessions s LEFT JOIN samples p ON p.session_id=s.id WHERE s.package_name=? GROUP BY s.id ORDER BY s.started_at DESC LIMIT 50", arrayOf(packageName)).use { c ->
            while (c.moveToNext()) {
                val id = c.getLong(0)
                result += SessionSummary(id, c.getString(1), c.getString(2), c.getLong(3), c.getLong(4), if (c.isNull(5)) null else c.getDouble(5), sessionOnePercentLow(id), if (c.isNull(6)) null else c.getDouble(6), if (c.isNull(7)) null else c.getDouble(7), if (c.isNull(8)) null else c.getDouble(8), if (c.isNull(9)) null else c.getDouble(9), c.getInt(10))
            }
        }
        return result
    }

    /** Session 1% low from the slowest 1% of stored frame-time samples (or fallback estimates). */
    private fun sessionOnePercentLow(sessionId: Long): Double? {
        val values = mutableListOf<Double>()
        readableDatabase.rawQuery("SELECT frame_time_ms FROM frame_intervals WHERE session_id=? ORDER BY frame_time_ms DESC", arrayOf(sessionId.toString())).use { c ->
            while (c.moveToNext()) values += c.getDouble(0)
        }
        if (values.isNotEmpty()) {
            val count = kotlin.math.ceil(values.size * 0.01).toInt().coerceAtLeast(1)
            val slowestFrameTime = values.take(count).average()
            return if (slowestFrameTime > 0.0) 1000.0 / slowestFrameTime else null
        }
        readableDatabase.rawQuery("SELECT fps FROM samples WHERE session_id=? AND fps IS NOT NULL ORDER BY fps ASC", arrayOf(sessionId.toString())).use { c ->
            while (c.moveToNext()) values += c.getDouble(0)
        }
        if (values.isEmpty()) return null
        val count = kotlin.math.ceil(values.size * 0.01).toInt().coerceAtLeast(1)
        return values.take(count).average()
    }
    @Synchronized fun closeAbandonedSessions(at: Long = System.currentTimeMillis()) {
        writableDatabase.update("sessions", ContentValues().apply { put("ended_at", at) }, "ended_at=0", null)
    }
    @Synchronized fun activeSession(packageName: String): Long? = readableDatabase.rawQuery("SELECT id FROM sessions WHERE package_name=? AND ended_at=0 ORDER BY started_at DESC LIMIT 1", arrayOf(packageName)).use { if (it.moveToFirst()) it.getLong(0) else null }
}
