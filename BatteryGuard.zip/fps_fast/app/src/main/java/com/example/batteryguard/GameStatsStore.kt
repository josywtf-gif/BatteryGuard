package com.example.batteryguard

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

/** Persistent per-game session history. OSD settings never clear or reset these records. */
class GameStatsStore(context: Context) : SQLiteOpenHelper(context, "game_stats.db", null, 2) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE sessions (id INTEGER PRIMARY KEY AUTOINCREMENT, package_name TEXT NOT NULL, app_name TEXT NOT NULL, started_at INTEGER NOT NULL, ended_at INTEGER NOT NULL DEFAULT 0)")
        db.execSQL("CREATE INDEX sessions_package_started ON sessions(package_name, started_at DESC)")
        db.execSQL("CREATE TABLE samples (id INTEGER PRIMARY KEY AUTOINCREMENT, session_id INTEGER NOT NULL, captured_at INTEGER NOT NULL, cpu_temp REAL, battery_temp REAL, ram_used_mb INTEGER, FOREIGN KEY(session_id) REFERENCES sessions(id))")
        db.execSQL("CREATE INDEX samples_session_time ON samples(session_id, captured_at)")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) db.execSQL("DROP TABLE IF EXISTS frame_intervals")
    }

    @Synchronized fun startSession(packageName: String, appName: String, at: Long = System.currentTimeMillis()): Long {
        val values = ContentValues().apply { put("package_name", packageName); put("app_name", appName); put("started_at", at); put("ended_at", 0L) }
        return writableDatabase.insert("sessions", null, values)
    }
    @Synchronized fun finishSession(id: Long, at: Long = System.currentTimeMillis()) {
        writableDatabase.update("sessions", ContentValues().apply { put("ended_at", at) }, "id=?", arrayOf(id.toString()))
    }
    @Synchronized fun addSample(id: Long, cpu: Double?, battery: Double?, ram: Long?) {
        val values = ContentValues().apply {
            put("session_id", id); put("captured_at", System.currentTimeMillis())
            putNullable("cpu_temp", cpu); putNullable("battery_temp", battery)
            if (ram != null) put("ram_used_mb", ram)
        }
        writableDatabase.insert("samples", null, values)
    }
    private fun ContentValues.putNullable(key: String, value: Double?) { if (value == null || value.isNaN() || value.isInfinite()) putNull(key) else put(key, value) }

    data class SessionSummary(val id: Long, val packageName: String, val appName: String, val startedAt: Long, val endedAt: Long, val avgCpuTemp: Double?, val maxCpuTemp: Double?, val avgBatteryTemp: Double?, val maxBatteryTemp: Double?, val avgRamMb: Double?, val sampleCount: Int)
    @Synchronized fun sessions(packageName: String): List<SessionSummary> {
        val result = mutableListOf<SessionSummary>()
        readableDatabase.rawQuery("SELECT s.id,s.package_name,s.app_name,s.started_at,s.ended_at,AVG(p.cpu_temp),MAX(p.cpu_temp),AVG(p.battery_temp),MAX(p.battery_temp),AVG(p.ram_used_mb),COUNT(p.id) FROM sessions s LEFT JOIN samples p ON p.session_id=s.id WHERE s.package_name=? GROUP BY s.id ORDER BY s.started_at DESC LIMIT 50", arrayOf(packageName)).use { c ->
            while (c.moveToNext()) {
                fun d(i: Int) = if (c.isNull(i)) null else c.getDouble(i)
                result += SessionSummary(c.getLong(0), c.getString(1), c.getString(2), c.getLong(3), c.getLong(4), d(5), d(6), d(7), d(8), d(9), c.getInt(10))
            }
        }
        return result
    }
    @Synchronized fun closeAbandonedSessions(at: Long = System.currentTimeMillis()) {
        writableDatabase.update("sessions", ContentValues().apply { put("ended_at", at) }, "ended_at=0", null)
    }
    @Synchronized fun activeSession(packageName: String): Long? = readableDatabase.rawQuery("SELECT id FROM sessions WHERE package_name=? AND ended_at=0 ORDER BY started_at DESC LIMIT 1", arrayOf(packageName)).use { if (it.moveToFirst()) it.getLong(0) else null }
}
