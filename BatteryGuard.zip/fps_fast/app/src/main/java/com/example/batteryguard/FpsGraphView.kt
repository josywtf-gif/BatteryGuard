package com.example.batteryguard

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.view.View
import kotlin.math.max

/** Compact rolling frame-time graph. Each point is a measured presented-frame interval. */
class FpsGraphView(context: Context) : View(context) {
    private val grid = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x447F8C9A; strokeWidth = dp(1f) }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF43C8FF.toInt(); strokeWidth = dp(2f); style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x3343C8FF; style = Paint.Style.FILL }
    private val path = Path()
    private val label = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF9BA8B8.toInt(); textSize = dp(8f); typeface = android.graphics.Typeface.DEFAULT_BOLD }
    private fun dp(v: Float) = v * resources.displayMetrics.density

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val left = dp(4f); val right = width - dp(4f); val top = dp(5f); val bottom = height - dp(5f)
        if (right <= left || bottom <= top) return
        canvas.drawText("FRAME TIME · ms", left, top + dp(8f), label)
        for (i in 0..2) {
            val y = top + (bottom - top) * i / 2f
            canvas.drawLine(left, y, right, y, grid)
        }
        val values = FpsReader.frameTimeGraphSamples
        if (values.size < 2) return
        val minValue = 0f
        val maxValue = max(20f, (values.maxOrNull() ?: 20f) * 1.10f)
        path.reset()
        values.forEachIndexed { index, value ->
            val x = left + (right - left) * index / (values.size - 1).toFloat()
            val y = bottom - ((value - minValue) / (maxValue - minValue)).coerceIn(0f, 1f) * (bottom - top)
            if (index == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        val area = Path(path).apply { lineTo(right, bottom); lineTo(left, bottom); close() }
        canvas.drawPath(area, fill)
        canvas.drawPath(path, line)
    }
}
