package com.example.batteryguard

import android.content.Context
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.WindowManager
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

class FloatingBubble(private val ctx: Context, type: Int = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY) {
    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val root = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_VERTICAL }
    private val rows = LinkedHashMap<String, TextView>()
    private val rowViews = LinkedHashMap<String, LinearLayout>()
    private val lp = WindowManager.LayoutParams(
        px(180), px(80), type,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
        PixelFormat.TRANSLUCENT
    ).apply {
        // Fixed to the top-left corner. Touches pass through to the game underneath.
        gravity = Gravity.TOP or Gravity.START
        x = 0
        y = 0
        // Прижать к самому углу экрана, включая зону вывыреза/боковых отступов.
        if (android.os.Build.VERSION.SDK_INT >= 30) layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        else if (android.os.Build.VERSION.SDK_INT >= 28) layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
    }
    private var shown = false
    private var textSizeSp = 14f
    private var rowHeightPx = px(30)
    private var configuredKeys: List<String> = emptyList()
    private var configuredStyle = "classic"
    private var configuredVoltageDetails = false

    private var insetLeft = 0
    private var insetTop = 0

    init {
        // Фон окна уходит за край экрана, а текст сдвигается на ширину выреза/скруглений.
        root.setOnApplyWindowInsetsListener { v, insets ->
            var l = 0; var t = 0
            if (android.os.Build.VERSION.SDK_INT >= 28) insets.displayCutout?.let { l = it.safeInsetLeft; t = it.safeInsetTop }
            if (l != insetLeft || t != insetTop) {
                insetLeft = l; insetTop = t
                val keys = configuredKeys
                configuredKeys = emptyList()
                applySize(Prefs.size(ctx), keys)
            }
            insets
        }
        applySize(Prefs.size(ctx), Prefs.metrics(ctx).filter { it != "voltage" })
        applyAlpha(Prefs.alpha(ctx))
    }

    private fun px(dp: Int) = (dp * ctx.resources.displayMetrics.density).toInt()
    private fun label(key: String) = when (key) {
        "cpu_temp" -> "CPU"
        "battery_temp" -> "BATT"
        "ram" -> "RAM"
        "time" -> "TIME"
        "battery" -> "CHARGE"
        else -> key.uppercase()
    }
    private fun iconRes(key: String): Int = when (key) {
        "cpu_temp" -> R.drawable.ic_cpu_temp
        "battery_temp" -> R.drawable.ic_battery_temp
        "ram" -> R.drawable.ic_ram
        "time" -> R.drawable.ic_clock
        "battery" -> R.drawable.ic_charge
        else -> R.drawable.ic_thermo
    }
    private fun accent(key: String): Int = when (key) {
        "cpu_temp" -> 0xFFFFA23A.toInt()
        "battery_temp" -> 0xFFFFC15A.toInt()
        "ram" -> 0xFF31C8A0.toInt()
        "time" -> 0xFFFFD166.toInt()
        "battery" -> 0xFF83C98B.toInt()
        else -> Color.WHITE
    }

    private fun createClassicRow(key: String): Pair<LinearLayout, TextView> {
        val iconSlot = LinearLayout(ctx).apply { gravity = Gravity.CENTER; layoutParams = LinearLayout.LayoutParams(px(28), rowHeightPx) }
        val icon = ImageView(ctx).apply {
            setImageResource(iconRes(key)); setColorFilter(accent(key)); scaleType = ImageView.ScaleType.FIT_CENTER
            layoutParams = LinearLayout.LayoutParams(px(21), px(21)); contentDescription = label(key)
        }
        iconSlot.addView(icon)
        val tv = TextView(ctx).apply {
            setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD
            setTextSize(TypedValue.COMPLEX_UNIT_SP, textSizeSp); maxLines = 1
            ellipsize = TextUtils.TruncateAt.END; includeFontPadding = false; gravity = Gravity.CENTER_VERTICAL
        }
        val row = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(-1, rowHeightPx)
            addView(iconSlot); addView(tv, LinearLayout.LayoutParams(0, -1, 1f).apply { marginStart = px(5) })
        }
        return row to tv
    }

    private fun createRtssRow(key: String): Pair<LinearLayout, TextView> {
        val name = TextView(ctx).apply {
            text = label(key); setTextColor(accent(key)); typeface = Typeface.create("monospace", Typeface.BOLD)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, textSizeSp * 0.78f); includeFontPadding = false
            gravity = Gravity.CENTER_VERTICAL; maxLines = 1
            layoutParams = LinearLayout.LayoutParams(px(50), rowHeightPx)
        }
        val value = TextView(ctx).apply {
            setTextColor(Color.WHITE); typeface = Typeface.create("monospace", Typeface.BOLD)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, textSizeSp * 0.88f); includeFontPadding = false
            gravity = Gravity.CENTER_VERTICAL; maxLines = 1; ellipsize = TextUtils.TruncateAt.END
        }
        val row = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(-1, rowHeightPx)
            addView(name); addView(value, LinearLayout.LayoutParams(0, -1, 1f).apply { marginStart = px(5) })
        }
        return row to value
    }

    /** Window geometry changes only when text size, enabled metrics, or OSD style changes. */
    fun applySize(dp: Int, metricKeys: List<String> = configuredKeys) {
        val keys = metricKeys.distinct()
        val style = Prefs.overlayStyle(ctx)
        val oldWidth = lp.width; val oldHeight = lp.height
        val newTextSize = (dp * 0.30f).coerceIn(12f, 24f)
        val newRowHeight = px(maxOf(24, (newTextSize * 1.45f).toInt()))
        val keysChanged = configuredKeys != keys || configuredStyle != style
        val sizeChanged = textSizeSp != newTextSize || rowHeightPx != newRowHeight
        val voltageDetails = Prefs.voltageDetailsEnabled(ctx)
        val contentChanged = configuredVoltageDetails != voltageDetails
        if (!keysChanged && !sizeChanged && !contentChanged) return
        textSizeSp = newTextSize; rowHeightPx = newRowHeight

        val samples = mapOf(
            "cpu_temp" to "99.9 °C", "battery_temp" to "99.9 °C", "ram" to "9999 / 9999 MB",
            "time" to "23:59", "battery" to if (voltageDetails) "100% · 4.50 В · −999 мА" else "100%"
        )
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            typeface = if (style == "rtss") Typeface.create("monospace", Typeface.BOLD) else Typeface.DEFAULT_BOLD
            textSize = textSizeSp * ctx.resources.displayMetrics.scaledDensity
        }
        val widest = keys.maxOfOrNull { key ->
            val textWidth = paint.measureText(samples[key] ?: "н/д")
            if (style == "rtss") textWidth + px(58) else textWidth + px(33)
        } ?: px(70).toFloat()
        val pad = if (style == "rtss") px(16) else px(16)
        val desiredWidth = (widest + pad).toInt()
        val screenWidth = ctx.resources.displayMetrics.widthPixels
        lp.width = desiredWidth.coerceIn(px(92), (screenWidth - px(16)).coerceAtLeast(px(92))) + insetLeft
        val contentHeight = keys.size * rowHeightPx
        lp.height = contentHeight.coerceAtLeast(rowHeightPx) + (if (style == "rtss") px(8) else px(12)) + insetTop
        configuredKeys = keys; configuredStyle = style; configuredVoltageDetails = voltageDetails

        // Панель «выезжает из угла»: скруглён только нижний правый угол, рамка и закругления
        // у верхнего/левого края уходят за пределы экрана.
        val r = (if (style == "rtss") px(6) else px(18)).toFloat()
        val bg = GradientDrawable().apply {
            cornerRadii = floatArrayOf(0f, 0f, 0f, 0f, r, r, 0f, 0f)
            setColor(if (style == "rtss") Color.argb(218, 8, 10, 12) else Color.argb(238, 25, 32, 46))
            if (style == "rtss") setStroke(px(1), Color.argb(100, 150, 150, 150))
        }
        root.background = android.graphics.drawable.LayerDrawable(arrayOf(bg)).apply { setLayerInset(0, -px(2), -px(2), 0, 0) }
        root.setPadding(insetLeft + px(10), insetTop + (if (style == "rtss") px(4) else px(6)), px(8), if (style == "rtss") px(4) else px(6))
        if (keysChanged) rebuildRows(keys, style)
        else if (sizeChanged) {
            rowViews.values.forEach { row ->
                row.layoutParams = LinearLayout.LayoutParams(-1, rowHeightPx)
                if (style == "classic") {
                    (row.getChildAt(0) as? LinearLayout)?.layoutParams = LinearLayout.LayoutParams(px(28), rowHeightPx)
                    (row.getChildAt(0) as? LinearLayout)?.getChildAt(0)?.layoutParams = LinearLayout.LayoutParams(px(21), px(21))
                    (row.getChildAt(1) as? TextView)?.setTextSize(TypedValue.COMPLEX_UNIT_SP, textSizeSp)
                } else {
                    (row.getChildAt(0) as? TextView)?.setTextSize(TypedValue.COMPLEX_UNIT_SP, textSizeSp * 0.78f)
                    (row.getChildAt(1) as? TextView)?.setTextSize(TypedValue.COMPLEX_UNIT_SP, textSizeSp * 0.88f)
                }
            }
        }
        if (shown && (oldWidth != lp.width || oldHeight != lp.height || keysChanged || sizeChanged)) {
            try { wm.updateViewLayout(root, lp) } catch (_: Exception) {}
        }
    }

    private fun rebuildRows(keys: List<String>, style: String) {
        root.removeAllViews(); rows.clear(); rowViews.clear()
        keys.forEach { key ->
            val (row, text) = if (style == "rtss") createRtssRow(key) else createClassicRow(key)
            root.addView(row); rows[key] = text; rowViews[key] = row
        }
    }

    fun applyAlpha(percent: Int) { root.alpha = percent.coerceIn(30, 100) / 100f }

    fun show(values: Map<String, String>) {
        val displayValues = values
        val keys = displayValues.keys.toList(); applySize(Prefs.size(ctx), keys)
        var textChanged = false
        displayValues.forEach { (key, value) ->
            val view = rows[key]
            if (view != null && view.text.toString() != value) { view.text = value; textChanged = true }
        }
        if (!shown) try { wm.addView(root, lp); shown = true } catch (_: Exception) {}
        if (shown && textChanged) root.invalidate()
    }

    fun hide() { if (shown) try { wm.removeView(root) } catch (_: Exception) {}; shown = false }
}
