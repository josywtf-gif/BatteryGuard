package com.example.batteryguard

import android.content.Context
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.os.Build
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

class FloatingBubble(private val ctx: Context, type: Int = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY) {
    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val root = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_VERTICAL }
    private val rows = LinkedHashMap<String, TextView>()
    private val lp = WindowManager.LayoutParams(
        px(180), px(80), type,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
        PixelFormat.TRANSLUCENT
    ).apply {
        gravity = Gravity.TOP or Gravity.START
        x = 0
        y = 0
        if (Build.VERSION.SDK_INT >= 30) layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        else if (Build.VERSION.SDK_INT >= 28) layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
    }
    private var shown = false
    private var textSizeSp = 14f
    private var rowHeightPx = px(30)
    private var configuredKeys: List<String> = emptyList()
    private var configuredStyle = ""
    private var configuredVoltageDetails = false
    private var insetLeft = 0

    init {
        // Фон уходит за левый край экрана; текст сдвигается только на боковой вырез (в альбомной ориентации).
        // Верхний вырез не учитывается: в портрете строка состояния используется под значения.
        root.setOnApplyWindowInsetsListener { _, insets ->
            val l = if (Build.VERSION.SDK_INT >= 28) insets.displayCutout?.safeInsetLeft ?: 0 else 0
            if (l != insetLeft) {
                insetLeft = l
                val keys = configuredKeys
                configuredKeys = emptyList()
                applySize(Prefs.size(ctx), keys)
            }
            insets
        }
        applySize(Prefs.size(ctx), Prefs.metrics(ctx).filter { it != "voltage" })
        applyAlpha(Prefs.alpha(ctx))
    }

    private fun px(dp: Int) = (dp * ctx.resources.displayMetrics.density).toInt()
    private fun label(key: String) = when (key) {
        "cpu_temp" -> "CPU"
        "battery_temp" -> "BATT"
        "ram" -> "RAM"
        "time" -> "TIME"
        "battery" -> "CHARGE"
        else -> key.uppercase()
    }
    private fun iconRes(key: String): Int = when (key) {
        "cpu_temp" -> R.drawable.ic_cpu_temp
        "battery_temp" -> R.drawable.ic_battery_temp
        "ram" -> R.drawable.ic_ram
        "time" -> R.drawable.ic_clock
        "battery" -> R.drawable.ic_charge
        else -> R.drawable.ic_thermo
    }
    private fun accent(key: String): Int = when (key) {
        "cpu_temp" -> 0xFFFFA23A.toInt()
        "battery_temp" -> 0xFFFFC15A.toInt()
        "ram" -> 0xFF31C8A0.toInt()
        "time" -> 0xFFFFD166.toInt()
        "battery" -> 0xFF83C98B.toInt()
        else -> Color.WHITE
    }

    private val iconSlotPx get() = px(28)
    private val iconPx get() = px(21)
    private fun isMono(style: String) = style == "rtss"
    private fun valueTypeface(style: String) = if (isMono(style)) Typeface.create("monospace", Typeface.BOLD) else Typeface.DEFAULT_BOLD
    private fun valueSizeSp(style: String) = if (style == "rtss") textSizeSp * 0.88f else textSizeSp

    /** Иконка в квадратной ячейке фиксированного размера: центры всех иконок на одной вертикали и в центре строки. */
    private fun iconCell(key: String, slot: Int = iconSlotPx, size: Int = iconPx, tint: Int = accent(key)) = LinearLayout(ctx).apply {
        gravity = Gravity.CENTER
        layoutParams = LinearLayout.LayoutParams(slot, rowHeightPx)
        addView(ImageView(ctx).apply {
            setImageResource(iconRes(key)); setColorFilter(tint); scaleType = ImageView.ScaleType.FIT_CENTER
            layoutParams = LinearLayout.LayoutParams(size, size); contentDescription = label(key)
        })
    }

    private fun valueText(style: String, key: String) = TextView(ctx).apply {
        setTextColor(if (style == "neon") accent(key) else Color.WHITE)
        typeface = valueTypeface(style)
        setTextSize(TypedValue.COMPLEX_UNIT_SP, valueSizeSp(style)); maxLines = 1
        ellipsize = TextUtils.TruncateAt.END; includeFontPadding = false; gravity = Gravity.CENTER_VERTICAL
        if (style == "minimal") setShadowLayer(px(3).toFloat(), 0f, px(1).toFloat(), Color.BLACK)
    }

    private fun createRow(style: String, key: String): Pair<View, TextView> {
        return when (style) {
            "rtss" -> {
                val name = TextView(ctx).apply {
                    text = label(key); setTextColor(accent(key)); typeface = Typeface.create("monospace", Typeface.BOLD)
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, textSizeSp * 0.78f); includeFontPadding = false
                    gravity = Gravity.CENTER_VERTICAL; maxLines = 1
                    layoutParams = LinearLayout.LayoutParams(px(50), rowHeightPx)
                }
                val value = valueText(style, key)
                val row = LinearLayout(ctx).apply {
                    orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                    layoutParams = LinearLayout.LayoutParams(-1, rowHeightPx)
                    addView(name); addView(value, LinearLayout.LayoutParams(0, -1, 1f).apply { marginStart = px(5) })
                }
                row to value
            }
            "compact" -> {
                val value = valueText(style, key)
                val cell = LinearLayout(ctx).apply {
                    orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                    layoutParams = LinearLayout.LayoutParams(-2, rowHeightPx).apply { marginEnd = px(10) }
                    addView(iconCell(key, px(22), px(18)))
                    addView(value, LinearLayout.LayoutParams(-2, -1).apply { marginStart = px(3) })
                }
                cell to value
            }
            else -> { // classic, minimal, neon
                val value = valueText(style, key)
                val row = LinearLayout(ctx).apply {
                    orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                    layoutParams = LinearLayout.LayoutParams(-1, rowHeightPx)
                    addView(iconCell(key))
                    addView(value, LinearLayout.LayoutParams(0, -1, 1f).apply { marginStart = px(5) })
                }
                row to value
            }
        }
    }

    private fun styleBackground(style: String): LayerDrawable {
        // Скруглён только нижний правый угол; рамка у верхнего и левого краёв уходит за экран.
        val r = when (style) { "rtss" -> px(6); "minimal" -> 0; "neon" -> px(10); "compact" -> px(12); else -> px(18) }.toFloat()
        val bg = GradientDrawable().apply {
            cornerRadii = floatArrayOf(0f, 0f, 0f, 0f, r, r, 0f, 0f)
            when (style) {
                "rtss" -> { setColor(Color.argb(218, 8, 10, 12)); setStroke(px(1), Color.argb(100, 150, 150, 150)) }
                "minimal" -> setColor(Color.TRANSPARENT)
                "neon" -> { setColor(Color.argb(235, 6, 8, 14)); setStroke(px(2), Color.argb(230, 67, 200, 255)) }
                "compact" -> setColor(Color.argb(225, 14, 18, 26))
                else -> setColor(Color.argb(238, 25, 32, 46))
            }
        }
        return LayerDrawable(arrayOf(bg)).apply { setLayerInset(0, -px(3), -px(3), 0, 0) }
    }

    /** Window geometry changes only when text size, enabled metrics, or style changes. */
    fun applySize(dp: Int, metricKeys: List<String> = configuredKeys) {
        val keys = metricKeys.distinct()
        val style = Prefs.overlayStyle(ctx)
        val oldWidth = lp.width; val oldHeight = lp.height
        val newTextSize = (dp * 0.30f).coerceIn(12f, 24f)
        val newRowHeight = px(maxOf(24, (newTextSize * 1.45f).toInt()))
        val keysChanged = configuredKeys != keys || configuredStyle != style
        val sizeChanged = textSizeSp != newTextSize || rowHeightPx != newRowHeight
        val voltageDetails = Prefs.voltageDetailsEnabled(ctx)
        val contentChanged = configuredVoltageDetails != voltageDetails
        if (!keysChanged && !sizeChanged && !contentChanged) return
        textSizeSp = newTextSize; rowHeightPx = newRowHeight

        val samples = mapOf(
            "cpu_temp" to "99.9 °C", "battery_temp" to "99.9 °C", "ram" to "9999 / 9999 MB",
            "time" to "23:59", "battery" to if (voltageDetails) "100% · 4.50 В · −999 мА" else "100%"
        )
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            typeface = valueTypeface(style)
            textSize = valueSizeSp(style) * ctx.resources.displayMetrics.scaledDensity
        }
        val screenWidth = ctx.resources.displayMetrics.widthPixels
        val padH = px(10) + px(8)
        val padV = if (style == "rtss") px(4) else px(6)
        val contentWidth: Float
        val contentHeight: Int
        if (style == "compact") {
            contentWidth = keys.sumOf { (paint.measureText(samples[it] ?: "н/д") + px(22) + px(3) + px(10)).toDouble() }.toFloat() - px(10)
            contentHeight = rowHeightPx
            root.orientation = LinearLayout.HORIZONTAL
        } else {
            val extra = if (style == "rtss") px(55) else px(33)
            contentWidth = keys.maxOfOrNull { paint.measureText(samples[it] ?: "н/д") + extra } ?: px(70).toFloat()
            contentHeight = keys.size * rowHeightPx
            root.orientation = LinearLayout.VERTICAL
        }
        val desired = (contentWidth + padH).toInt() + insetLeft
        lp.width = desired.coerceIn(px(92), screenWidth.coerceAtLeast(px(92)))
        lp.height = contentHeight.coerceAtLeast(rowHeightPx) + padV * 2
        configuredKeys = keys; configuredStyle = style; configuredVoltageDetails = voltageDetails

        root.background = styleBackground(style)
        root.gravity = if (style == "compact") Gravity.CENTER_VERTICAL else Gravity.CENTER_VERTICAL
        root.setPadding(insetLeft + px(10), padV, px(8), padV)
        if (keysChanged || sizeChanged) rebuildRows(keys, style)
        if (shown && (oldWidth != lp.width || oldHeight != lp.height || keysChanged || sizeChanged)) {
            try { wm.updateViewLayout(root, lp) } catch (_: Exception) {}
        }
    }

    private fun rebuildRows(keys: List<String>, style: String) {
        val old = rows.mapValues { it.value.text }
        root.removeAllViews(); rows.clear()
        keys.forEach { key ->
            val (view, text) = createRow(style, key)
            old[key]?.let { text.text = it }
            root.addView(view); rows[key] = text
        }
    }

    fun applyAlpha(percent: Int) { root.alpha = percent.coerceIn(30, 100) / 100f }

    fun show(values: Map<String, String>) {
        val keys = values.keys.toList(); applySize(Prefs.size(ctx), keys)
        var textChanged = false
        values.forEach { (key, value) ->
            val view = rows[key]
            if (view != null && view.text.toString() != value) { view.text = value; textChanged = true }
        }
        if (!shown) try { wm.addView(root, lp); shown = true } catch (_: Exception) {}
        if (shown && textChanged) root.invalidate()
    }

    fun hide() { if (shown) try { wm.removeView(root) } catch (_: Exception) {}; shown = false }
}
