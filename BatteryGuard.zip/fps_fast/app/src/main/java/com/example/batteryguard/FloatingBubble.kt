package com.example.batteryguard

import android.content.Context
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.WindowManager
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

class FloatingBubble(private val ctx: Context, type: Int = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY) {
    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val root = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_VERTICAL }
    private val rows = LinkedHashMap<String, TextView>()
    private val rowViews = LinkedHashMap<String, LinearLayout>()
    private val graphViews = LinkedHashMap<String, FpsGraphView>()
    private val lp = WindowManager.LayoutParams(
        px(180), px(80), type,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
        PixelFormat.TRANSLUCENT
    ).apply {
        // Fixed to the top-left corner. Touches pass through to the game underneath.
        gravity = Gravity.TOP or Gravity.START
        x = 0
        y = 0
    }
    private var shown = false
    private var textSizeSp = 14f
    private var rowHeightPx = px(30)
    private var configuredKeys: List<String> = emptyList()
    private var configuredStyle = "classic"
    private var configuredVoltageDetails = false

    init {
        applySize(Prefs.size(ctx), Prefs.metrics(ctx).filter { it != "voltage" })
        applyAlpha(Prefs.alpha(ctx))
    }

    private fun px(dp: Int) = (dp * ctx.resources.displayMetrics.density).toInt()
    private fun label(key: String) = when (key) {
        "cpu_temp" -> "CPU"
        "battery_temp" -> "BATT"
        "ram" -> "RAM"
        "time" -> "TIME"
        "battery" -> "CHARGE"
        "fps", "fps_summary" -> "FPS"
        "fps_avg" -> "AVG"
        "fps_1low" -> "1% LOW"
        "frametime" -> "FRAME"
        "frametime_graph" -> "FRAME GRAPH"
        else -> key.uppercase()
    }
    private fun iconRes(key: String): Int = when (key) {
        "cpu_temp" -> R.drawable.ic_cpu_temp
        "battery_temp" -> R.drawable.ic_battery_temp
        "ram" -> R.drawable.ic_ram
        "time" -> R.drawable.ic_clock
        "battery" -> R.drawable.ic_charge
        "fps", "fps_summary", "fps_avg", "fps_1low" -> R.drawable.ic_cpu
        "frametime", "frametime_graph" -> R.drawable.ic_cpu
        else -> R.drawable.ic_thermo
    }
    private fun accent(key: String): Int = when (key) {
        "cpu_temp" -> 0xFFFFA23A.toInt()
        "battery_temp" -> 0xFFFFC15A.toInt()
        "ram" -> 0xFF31C8A0.toInt()
        "time" -> 0xFFFFD166.toInt()
        "battery" -> 0xFF83C98B.toInt()
        "fps", "fps_summary", "fps_avg", "fps_1low", "frametime", "frametime_graph" -> 0xFF43C8FF.toInt()
        else -> Color.WHITE
    }

    private fun createClassicRow(key: String): Pair<LinearLayout, TextView> {
        val iconSlot = LinearLayout(ctx).apply { gravity = Gravity.CENTER; layoutParams = LinearLayout.LayoutParams(px(28), rowHeightPx) }
        val icon = ImageView(ctx).apply {
            setImageResource(iconRes(key)); setColorFilter(accent(key)); scaleType = ImageView.ScaleType.FIT_CENTER
            layoutParams = LinearLayout.LayoutParams(px(21), px(21)); contentDescription = label(key)
        }
        iconSlot.addView(icon)
        val tv = TextView(ctx).apply {
            setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD
            setTextSize(TypedValue.COMPLEX_UNIT_SP, textSizeSp); maxLines = 1
            ellipsize = TextUtils.TruncateAt.END; includeFontPadding = false; gravity = Gravity.CENTER_VERTICAL
        }
        val row = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(-1, rowHeightPx)
            addView(iconSlot); addView(tv, LinearLayout.LayoutParams(0, -1, 1f).apply { marginStart = px(5) })
        }
        return row to tv
    }

    /** Frametime is deliberately a plain text line without an icon. */
    private fun createPlainRow(key: String): Pair<LinearLayout, TextView> {
        val tv = TextView(ctx).apply {
            setTextColor(Color.WHITE)
            typeface = if (Prefs.overlayStyle(ctx) == "rtss") Typeface.create("monospace", Typeface.BOLD) else Typeface.DEFAULT_BOLD
            setTextSize(TypedValue.COMPLEX_UNIT_SP, textSizeSp)
            includeFontPadding = false
            gravity = Gravity.CENTER_VERTICAL
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            layoutParams = LinearLayout.LayoutParams(-1, rowHeightPx)
        }
        val row = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(-1, rowHeightPx)
            addView(tv)
        }
        return row to tv
    }

    private fun createRtssRow(key: String): Pair<LinearLayout, TextView> {
        val name = TextView(ctx).apply {
            text = label(key); setTextColor(accent(key)); typeface = Typeface.create("monospace", Typeface.BOLD)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, textSizeSp * 0.78f); includeFontPadding = false
            gravity = Gravity.CENTER_VERTICAL; maxLines = 1
            layoutParams = LinearLayout.LayoutParams(px(68), rowHeightPx)
        }
        val value = TextView(ctx).apply {
            setTextColor(Color.WHITE); typeface = Typeface.create("monospace", Typeface.BOLD)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, textSizeSp * 0.88f); includeFontPadding = false
            gravity = Gravity.CENTER_VERTICAL; maxLines = 1; ellipsize = TextUtils.TruncateAt.END
        }
        val row = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(-1, rowHeightPx)
            addView(name); addView(value, LinearLayout.LayoutParams(0, -1, 1f).apply { marginStart = px(5) })
        }
        return row to value
    }

    /** Window geometry changes only when text size, enabled metrics, or OSD style changes. */
    fun applySize(dp: Int, metricKeys: List<String> = configuredKeys) {
        val keys = metricKeys.distinct()
        val style = Prefs.overlayStyle(ctx)
        val oldWidth = lp.width; val oldHeight = lp.height
        val newTextSize = (dp * 0.30f).coerceIn(12f, 24f)
        val newRowHeight = px(maxOf(24, (newTextSize * 1.45f).toInt()))
        val keysChanged = configuredKeys != keys || configuredStyle != style
        val sizeChanged = textSizeSp != newTextSize || rowHeightPx != newRowHeight
        val voltageDetails = Prefs.voltageDetailsEnabled(ctx)
        val contentChanged = configuredVoltageDetails != voltageDetails
        if (!keysChanged && !sizeChanged && !contentChanged) return
        textSizeSp = newTextSize; rowHeightPx = newRowHeight

        val samples = mapOf(
            "cpu_temp" to "99.9 °C", "battery_temp" to "99.9 °C", "ram" to "9999 / 9999 MB",
            "time" to "23:59", "battery" to if (voltageDetails) "100% · 4.50 В · −999 мА" else "100%",
            "fps" to "240 FPS", "fps_summary" to "FPS 240   AVG 220   1% LOW 165", "fps_avg" to "220 FPS", "fps_1low" to "165 FPS",
            "frametime" to "Frame Time  6.9 ms", "frametime_graph" to ""
        )
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            typeface = if (style == "rtss") Typeface.create("monospace", Typeface.BOLD) else Typeface.DEFAULT_BOLD
            textSize = textSizeSp * ctx.resources.displayMetrics.scaledDensity
        }
        val widest = keys.maxOfOrNull { key ->
            if (key == "frametime_graph") px(150).toFloat() else {
                val textWidth = paint.measureText(samples[key] ?: "н/д")
                if (style == "rtss") textWidth + px(74) else textWidth + px(33)
            }
        } ?: px(70).toFloat()
        val pad = if (style == "rtss") px(16) else px(16)
        val desiredWidth = (widest + pad).toInt()
        val screenWidth = ctx.resources.displayMetrics.widthPixels
        lp.width = desiredWidth.coerceIn(px(92), (screenWidth - px(16)).coerceAtLeast(px(92)))
        val contentHeight = keys.sumOf { if (it == "frametime_graph") px(48) else rowHeightPx }
        lp.height = contentHeight.coerceAtLeast(rowHeightPx) + if (style == "rtss") px(8) else px(12)
        configuredKeys = keys; configuredStyle = style; configuredVoltageDetails = voltageDetails

        root.background = GradientDrawable().apply {
            cornerRadius = if (style == "rtss") px(3).toFloat() else px(18).toFloat()
            setColor(if (style == "rtss") Color.argb(218, 8, 10, 12) else Color.argb(238, 25, 32, 46))
            if (style == "rtss") setStroke(px(1), Color.argb(100, 150, 150, 150))
        }
        root.setPadding(px(8), if (style == "rtss") px(4) else px(6), px(8), if (style == "rtss") px(4) else px(6))
        if (keysChanged) rebuildRows(keys, style)
        else if (sizeChanged) {
            rowViews.values.forEach { row ->
                row.layoutParams = LinearLayout.LayoutParams(-1, rowHeightPx)
                if (row.tag == "plain_frametime") {
                    (row.getChildAt(0) as? TextView)?.setTextSize(TypedValue.COMPLEX_UNIT_SP, textSizeSp)
                } else if (style == "classic") {
                    (row.getChildAt(0) as? LinearLayout)?.layoutParams = LinearLayout.LayoutParams(px(28), rowHeightPx)
                    (row.getChildAt(0) as? LinearLayout)?.getChildAt(0)?.layoutParams = LinearLayout.LayoutParams(px(21), px(21))
                    (row.getChildAt(1) as? TextView)?.setTextSize(TypedValue.COMPLEX_UNIT_SP, textSizeSp)
                } else {
                    (row.getChildAt(0) as? TextView)?.setTextSize(TypedValue.COMPLEX_UNIT_SP, textSizeSp * 0.78f)
                    (row.getChildAt(1) as? TextView)?.setTextSize(TypedValue.COMPLEX_UNIT_SP, textSizeSp * 0.88f)
                }
            }
        }
        if (shown && (oldWidth != lp.width || oldHeight != lp.height || keysChanged || sizeChanged)) {
            try { wm.updateViewLayout(root, lp) } catch (_: Exception) {}
        }
    }

    private fun rebuildRows(keys: List<String>, style: String) {
        root.removeAllViews(); rows.clear(); rowViews.clear(); graphViews.clear()
        keys.forEach { key ->
            when (key) {
                "frametime_graph" -> {
                    val graph = FpsGraphView(ctx).apply { layoutParams = LinearLayout.LayoutParams(-1, px(48)) }
                    root.addView(graph); graphViews[key] = graph
                }
                "frametime" -> {
                    val (row, text) = createPlainRow(key)
                    row.tag = "plain_frametime"
                    root.addView(row); rows[key] = text; rowViews[key] = row
                }
                else -> {
                    val (row, text) = if (style == "rtss") createRtssRow(key) else createClassicRow(key)
                    root.addView(row); rows[key] = text; rowViews[key] = row
                }
            }
        }
    }

    /** Merge independently enabled FPS metrics into one compact line. Frame Time stays below it. */
    private fun compactValues(input: Map<String, String>): LinkedHashMap<String, String> {
        val out = LinkedHashMap<String, String>()
        val fpsKeys = listOf("fps" to "FPS", "fps_avg" to "AVG", "fps_1low" to "1% LOW")
        val hasFps = fpsKeys.any { input.containsKey(it.first) }
        input.forEach { (key, value) ->
            when {
                key in Prefs.FPS_METRICS && key != "frametime" && key != "frametime_graph" -> Unit
                key == "frametime" || key == "frametime_graph" -> Unit
                else -> out[key] = value
            }
        }
        // Keep the FPS triplet together, followed by the icon-free Frame Time line and graph.
        if (hasFps) {
            val parts = fpsKeys.filter { input.containsKey(it.first) }.map { (metric, label) ->
                val number = input[metric].orEmpty().removeSuffix(" FPS")
                "$label $number"
            }
            out["fps_summary"] = parts.joinToString("   ")
        }
        input["frametime"]?.let { out["frametime"] = "Frame Time  $it" }
        if (input.containsKey("frametime_graph")) out["frametime_graph"] = ""
        return out
    }

    fun applyAlpha(percent: Int) { root.alpha = percent.coerceIn(30, 100) / 100f }

    fun show(values: Map<String, String>) {
        val displayValues = compactValues(values)
        val keys = displayValues.keys.toList(); applySize(Prefs.size(ctx), keys)
        var textChanged = false
        displayValues.forEach { (key, value) ->
            val view = rows[key]
            if (view != null && view.text.toString() != value) { view.text = value; textChanged = true }
        }
        if (!shown) try { wm.addView(root, lp); shown = true } catch (_: Exception) {}
        // TextView invalidates itself when its value changes; graph redraws only its own view.
        graphViews.values.forEach { it.invalidate() }
        if (shown && textChanged) root.invalidate()
    }

    fun hide() { if (shown) try { wm.removeView(root) } catch (_: Exception) {}; shown = false }
}
