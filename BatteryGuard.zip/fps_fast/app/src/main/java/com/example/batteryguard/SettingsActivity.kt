package com.example.batteryguard

import android.content.ClipData
import android.os.Bundle
import android.view.DragEvent
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AlertDialog
import com.google.android.material.slider.Slider
import android.content.pm.PackageManager
import rikka.shizuku.Shizuku

class SettingsActivity : AppCompatActivity() {
    private val labels = mapOf(
        "cpu_temp" to "Температура CPU",
        "battery_temp" to "Температура батареи",
        "ram" to "ОЗУ",
        "time" to "Время",
        "battery" to "Заряд",
        "voltage" to "Вольтаж и потребление",
        "fps" to "Текущий FPS",
        "fps_avg" to "Средний FPS",
        "fps_1low" to "1% Low FPS",
        "frametime" to "Frame Time (мс)",
        "frametime_graph" to "График Frame Time"
    )
    private val icons = mapOf(
        "cpu_temp" to R.drawable.ic_cpu_temp,
        "battery_temp" to R.drawable.ic_battery_temp,
        "ram" to R.drawable.ic_ram,
        "time" to R.drawable.ic_clock,
        "battery" to R.drawable.ic_charge,
        "voltage" to R.drawable.ic_voltage,
        "fps" to R.drawable.ic_cpu,
        "fps_avg" to R.drawable.ic_cpu,
        "fps_1low" to R.drawable.ic_cpu,
        "frametime" to R.drawable.ic_cpu,
        "frametime_graph" to R.drawable.ic_cpu
    )
    private lateinit var list: LinearLayout
    private val fpsChecks = mutableMapOf<String, CheckBox>()
    private var pendingMetric: String = "fps"
    private var programmaticCheckChange = false
    private fun setMetricCheck(metric: String, checked: Boolean) {
        programmaticCheckChange = true
        fpsChecks[metric]?.isChecked = checked
        programmaticCheckChange = false
    }
    private val shizukuPermissionListener = Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
        if (requestCode == FPS_PERMISSION_REQUEST) {
            if (grantResult == PackageManager.PERMISSION_GRANTED) {
                val current = Prefs.metrics(this).toMutableList()
                if (pendingMetric !in current) current.add(pendingMetric)
                Prefs.setMetrics(this, current)
                FpsReader.connect(this)
                setMetricCheck(pendingMetric, true)
                Toast.makeText(this, "Доступ для измерения кадров разрешён", Toast.LENGTH_SHORT).show()
                sendRefresh()
            } else {
                setMetricCheck(pendingMetric, false)
                Toast.makeText(this, "Без разрешения FPS работать не будет", Toast.LENGTH_LONG).show()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
        findViewById<View>(R.id.btnBack).setOnClickListener { finish() }
        list = findViewById(R.id.metricsList)
        renderMetrics()
        Shizuku.addRequestPermissionResultListener(shizukuPermissionListener)

        val classic = findViewById<RadioButton>(R.id.styleClassic)
        val rtss = findViewById<RadioButton>(R.id.styleRtss)
        (if (Prefs.overlayStyle(this) == "rtss") rtss else classic).isChecked = true
        findViewById<RadioGroup>(R.id.overlayStyleGroup).setOnCheckedChangeListener { _, checkedId ->
            Prefs.setOverlayStyle(this, if (checkedId == R.id.styleRtss) "rtss" else "classic")
            sendRefresh()
        }
        val warningHeader = findViewById<LinearLayout>(R.id.sensorWarningHeader)
        val warningBody = findViewById<View>(R.id.sensorWarningBody)
        val warningArrow = findViewById<TextView>(R.id.sensorWarningArrow)
        // Предупреждение всегда свёрнуто при новом открытии экрана настроек.
        warningBody.visibility = View.GONE
        warningArrow.text = "⌄"
        warningHeader.setOnClickListener {
            val expanded = warningBody.visibility != View.VISIBLE
            warningBody.visibility = if (expanded) View.VISIBLE else View.GONE
            warningArrow.text = if (expanded) "⌃" else "⌄"
        }

        val size = findViewById<Slider>(R.id.sliderSize)
        val sizeText = findViewById<TextView>(R.id.tvSize)
        size.value = Prefs.size(this).toFloat().coerceIn(24f, 96f)
        sizeText.text = "${size.value.toInt()} dp"
        size.addOnChangeListener { _, value, fromUser ->
            sizeText.text = "${value.toInt()} dp"
            if (fromUser) { Prefs.setSize(this, value.toInt()); sendRefresh() }
        }
        val alpha = findViewById<Slider>(R.id.sliderAlpha)
        val alphaText = findViewById<TextView>(R.id.tvAlpha)
        alpha.value = Prefs.alpha(this).toFloat().coerceIn(30f, 100f)
        alphaText.text = "${alpha.value.toInt()}%"
        alpha.addOnChangeListener { _, value, fromUser ->
            alphaText.text = "${value.toInt()}%"
            if (fromUser) { Prefs.setAlpha(this, value.toInt()); sendRefresh() }
        }
    }

    override fun onResume() {
        super.onResume()
        // FPS capture is owned by MonitorService and runs for any foreground app while monitoring is on.
    }

    override fun onDestroy() {
        Shizuku.removeRequestPermissionResultListener(shizukuPermissionListener)
        super.onDestroy()
    }

    private fun requestFpsActivation(metric: String = "fps") {
        pendingMetric = metric
        val prefs = Prefs.sp(this)
        val firstActivation = !prefs.getBoolean("fps_permission_notice_shown", false)
        if (firstActivation) {
            AlertDialog.Builder(this)
                .setTitle("Доступ к статистике кадров")
                .setMessage("Для измерения реального FPS и Frame Time нужен Shizuku. Он предоставляет BatteryGuard системный доступ уровня ADB Shell через беспроводную отладку. Root не требуется. После подтверждения откроется Shizuku или появится системный запрос разрешения.")
                .setNegativeButton("Отмена") { _, _ -> setMetricCheck(pendingMetric, false) }
                .setPositiveButton("Продолжить") { _, _ ->
                    prefs.edit().putBoolean("fps_permission_notice_shown", true).apply()
                    continueFpsActivation()
                }
                .setOnCancelListener { setMetricCheck(pendingMetric, false) }
                .show()
        } else {
            continueFpsActivation()
        }
    }

    private fun continueFpsActivation() {
        if (!FpsReader.shizukuRunning()) {
            val launch = packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")
            if (launch != null) {
                startActivity(launch)
                Toast.makeText(this, "Запустите Shizuku, затем вернитесь и включите FPS", Toast.LENGTH_LONG).show()
            } else {
                AlertDialog.Builder(this)
                    .setTitle("Нужен Shizuku")
                    .setMessage("Установите Shizuku и запустите его через беспроводную отладку. Root не требуется. Затем вернитесь сюда и включите FPS.")
                    .setNegativeButton("Закрыть") { _, _ -> setMetricCheck(pendingMetric, false) }
                    .setPositiveButton("Открыть страницу загрузки") { _, _ ->
                        startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse("https://shizuku.rikka.app/download/")))
                        setMetricCheck(pendingMetric, false)
                    }
                    .show()
            }
            setMetricCheck(pendingMetric, false)
            return
        }
        if (FpsReader.hasShizukuPermission()) {
            val current = Prefs.metrics(this).toMutableList()
            if (pendingMetric !in current) current.add(pendingMetric)
            Prefs.setMetrics(this, current)
            FpsReader.connect(this)
            setMetricCheck(pendingMetric, true)
            sendRefresh()
        } else {
            try {
                Shizuku.requestPermission(FPS_PERMISSION_REQUEST)
            } catch (_: Throwable) {
                setMetricCheck(pendingMetric, false)
                Toast.makeText(this, "Не удалось запросить разрешение Shizuku", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun renderMetrics() {
        list.removeAllViews()
        val enabled = Prefs.metrics(this).toSet()
        Prefs.order(this).forEach { key ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(8, 7, 8, 7)
                tag = key
                minimumHeight = dp(54)
                setOnLongClickListener {
                    val clip = ClipData.newPlainText("metric", key)
                    startDragAndDrop(clip, View.DragShadowBuilder(this), key, 0)
                }
                setOnDragListener { target, event ->
                    when (event.action) {
                        DragEvent.ACTION_DRAG_STARTED -> true
                        DragEvent.ACTION_DRAG_ENTERED -> { target.alpha = 0.55f; true }
                        DragEvent.ACTION_DRAG_EXITED -> { target.alpha = 1f; true }
                        DragEvent.ACTION_DROP -> {
                            target.alpha = 1f
                            val fromKey = event.clipData.getItemAt(0).text?.toString()
                            val toKey = target.tag?.toString()
                            if (fromKey != null && toKey != null && fromKey != toKey) {
                                val order = Prefs.order(this@SettingsActivity)
                                val from = order.indexOf(fromKey)
                                val to = order.indexOf(toKey)
                                if (from >= 0 && to >= 0) {
                                    val moved = order.removeAt(from)
                                    order.add(to, moved)
                                    Prefs.setOrder(this@SettingsActivity, order)
                                    renderMetrics()
                                }
                            }
                            true
                        }
                        DragEvent.ACTION_DRAG_ENDED -> { target.alpha = 1f; true }
                        else -> true
                    }
                }
            }
            val icon = ImageView(this).apply {
                setImageResource(icons[key] ?: R.drawable.ic_thermo)
                setColorFilter(0xFF8AB4F8.toInt())
                scaleType = ImageView.ScaleType.FIT_CENTER
                layoutParams = LinearLayout.LayoutParams(dp(40), dp(40)).apply {
                    width = dp(40)
                    height = dp(40)
                    marginEnd = dp(8)
                }
                contentDescription = labels[key]
            }
            val check = CheckBox(this).apply {
                text = labels[key]
                isChecked = key in enabled
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                if (key in Prefs.FPS_METRICS) fpsChecks[key] = this
                setOnCheckedChangeListener { _, checked ->
                    if (programmaticCheckChange) return@setOnCheckedChangeListener
                    if (key in Prefs.FPS_METRICS && checked) {
                        setMetricCheck(key, false)
                        requestFpsActivation(key)
                        return@setOnCheckedChangeListener
                    }
                    val current = Prefs.metrics(this@SettingsActivity)
                    if (checked) { if (key !in current) current.add(key) } else current.remove(key)
                    Prefs.setMetrics(this@SettingsActivity, current)
                    sendRefresh()
                }
            }
            val handle = TextView(this).apply {
                text = "☰"
                textSize = 22f
                gravity = Gravity.CENTER
                contentDescription = "Удерживайте и перетащите для изменения порядка"
                setTextColor(0xFF8A94A6.toInt())
                layoutParams = LinearLayout.LayoutParams(dp(40), dp(40))
                setOnLongClickListener {
                    val clip = ClipData.newPlainText("metric", key)
                    row.startDragAndDrop(clip, View.DragShadowBuilder(row), key, 0)
                }
            }
            row.addView(icon)
            row.addView(check)
            row.addView(handle)
            list.addView(row)
            list.addView(View(this).apply { setBackgroundColor(0x22333333) }, LinearLayout.LayoutParams(-1, 1))
        }
    }

    companion object { private const val FPS_PERMISSION_REQUEST = 731 }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
    private fun sendRefresh() { if (Prefs.isEnabled(this)) startService(android.content.Intent(this, MonitorService::class.java)) }
}
