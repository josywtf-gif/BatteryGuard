package com.example.batteryguard

import android.content.ClipData
import android.os.Bundle
import android.view.DragEvent
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.slider.Slider

class SettingsActivity : AppCompatActivity() {
    private val labels = mapOf(
        "cpu_temp" to "Температура CPU",
        "battery_temp" to "Температура батареи",
        "ram" to "ОЗУ",
        "time" to "Время",
        "battery" to "Заряд",
        "voltage" to "Вольтаж и потребление"
    )
    private val icons = mapOf(
        "cpu_temp" to R.drawable.ic_cpu_temp,
        "battery_temp" to R.drawable.ic_battery_temp,
        "ram" to R.drawable.ic_ram,
        "time" to R.drawable.ic_clock,
        "battery" to R.drawable.ic_charge,
        "voltage" to R.drawable.ic_voltage
    )
    private lateinit var list: LinearLayout
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
        findViewById<View>(R.id.btnBack).setOnClickListener { finish() }
        list = findViewById(R.id.metricsList)
        renderMetrics()

        val styleGroup = findViewById<RadioGroup>(R.id.overlayStyleGroup)
        styleGroup.removeAllViews()
        val current = Prefs.overlayStyle(this)
        val styleViewIds = LinkedHashMap<Int, String>()
        Prefs.STYLE_LABELS.forEach { (key, title) ->
            val rb = RadioButton(this).apply { id = View.generateViewId(); text = title; isChecked = key == current }
            styleViewIds[rb.id] = key
            styleGroup.addView(rb, RadioGroup.LayoutParams(-1, -2))
        }
        styleGroup.setOnCheckedChangeListener { _, checkedId ->
            Prefs.setOverlayStyle(this, styleViewIds[checkedId] ?: "classic")
            sendRefresh()
        }
        val stylesArrow = findViewById<TextView>(R.id.stylesArrow)
        styleGroup.visibility = View.GONE
        findViewById<View>(R.id.stylesHeader).setOnClickListener {
            val expanded = styleGroup.visibility != View.VISIBLE
            styleGroup.visibility = if (expanded) View.VISIBLE else View.GONE
            stylesArrow.text = if (expanded) "⌃" else "⌄"
        }
        val warningHeader = findViewById<LinearLayout>(R.id.sensorWarningHeader)
        val warningBody = findViewById<View>(R.id.sensorWarningBody)
        val warningArrow = findViewById<TextView>(R.id.sensorWarningArrow)
        // Предупреждение всегда свёрнуто при новом открытии экрана настроек.
        warningBody.visibility = View.GONE
        warningArrow.text = "⌄"
        warningHeader.setOnClickListener {
            val expanded = warningBody.visibility != View.VISIBLE
            warningBody.visibility = if (expanded) View.VISIBLE else View.GONE
            warningArrow.text = if (expanded) "⌃" else "⌄"
        }

        val size = findViewById<Slider>(R.id.sliderSize)
        val sizeText = findViewById<TextView>(R.id.tvSize)
        size.value = Prefs.size(this).toFloat().coerceIn(24f, 96f)
        sizeText.text = "${size.value.toInt()} dp"
        size.addOnChangeListener { _, value, fromUser ->
            sizeText.text = "${value.toInt()} dp"
            if (fromUser) { Prefs.setSize(this, value.toInt()); sendRefresh() }
        }
        val alpha = findViewById<Slider>(R.id.sliderAlpha)
        val alphaText = findViewById<TextView>(R.id.tvAlpha)
        alpha.value = Prefs.alpha(this).toFloat().coerceIn(30f, 100f)
        alphaText.text = "${alpha.value.toInt()}%"
        alpha.addOnChangeListener { _, value, fromUser ->
            alphaText.text = "${value.toInt()}%"
            if (fromUser) { Prefs.setAlpha(this, value.toInt()); sendRefresh() }
        }
    }

    private fun renderMetrics() {
        list.removeAllViews()
        val enabled = Prefs.metrics(this).toSet()
        Prefs.order(this).forEach { key ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(8, 7, 8, 7)
                tag = key
                minimumHeight = dp(54)
                setOnLongClickListener {
                    val clip = ClipData.newPlainText("metric", key)
                    startDragAndDrop(clip, View.DragShadowBuilder(this), key, 0)
                }
                setOnDragListener { target, event ->
                    when (event.action) {
                        DragEvent.ACTION_DRAG_STARTED -> true
                        DragEvent.ACTION_DRAG_ENTERED -> { target.alpha = 0.55f; true }
                        DragEvent.ACTION_DRAG_EXITED -> { target.alpha = 1f; true }
                        DragEvent.ACTION_DROP -> {
                            target.alpha = 1f
                            val fromKey = event.clipData.getItemAt(0).text?.toString()
                            val toKey = target.tag?.toString()
                            if (fromKey != null && toKey != null && fromKey != toKey) {
                                val order = Prefs.order(this@SettingsActivity)
                                val from = order.indexOf(fromKey)
                                val to = order.indexOf(toKey)
                                if (from >= 0 && to >= 0) {
                                    val moved = order.removeAt(from)
                                    order.add(to, moved)
                                    Prefs.setOrder(this@SettingsActivity, order)
                                    renderMetrics()
                                }
                            }
                            true
                        }
                        DragEvent.ACTION_DRAG_ENDED -> { target.alpha = 1f; true }
                        else -> true
                    }
                }
            }
            val icon = ImageView(this).apply {
                setImageResource(icons[key] ?: R.drawable.ic_thermo)
                setColorFilter(0xFF8AB4F8.toInt())
                scaleType = ImageView.ScaleType.FIT_CENTER
                layoutParams = LinearLayout.LayoutParams(dp(40), dp(40)).apply {
                    width = dp(40)
                    height = dp(40)
                    marginEnd = dp(8)
                }
                contentDescription = labels[key]
            }
            val check = CheckBox(this).apply {
                text = labels[key]
                isChecked = key in enabled
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                setOnCheckedChangeListener { _, checked ->
                    val current = Prefs.metrics(this@SettingsActivity)
                    if (checked) { if (key !in current) current.add(key) } else current.remove(key)
                    Prefs.setMetrics(this@SettingsActivity, current)
                    sendRefresh()
                }
            }
            val handle = TextView(this).apply {
                text = "☰"
                textSize = 22f
                gravity = Gravity.CENTER
                contentDescription = "Удерживайте и перетащите для изменения порядка"
                setTextColor(0xFF8A94A6.toInt())
                layoutParams = LinearLayout.LayoutParams(dp(40), dp(40))
                setOnLongClickListener {
                    val clip = ClipData.newPlainText("metric", key)
                    row.startDragAndDrop(clip, View.DragShadowBuilder(row), key, 0)
                }
            }
            row.addView(icon)
            row.addView(check)
            row.addView(handle)
            list.addView(row)
            list.addView(View(this).apply { setBackgroundColor(0x22333333) }, LinearLayout.LayoutParams(-1, 1))
        }
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
    private fun sendRefresh() { if (Prefs.isEnabled(this)) startService(android.content.Intent(this, MonitorService::class.java)) }
}
